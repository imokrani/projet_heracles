package fr.gouv.finances.rloc.r7f.coordination;

import java.io.File;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.ContratApplicatif;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class Main
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);

    public static void main(String[] args)
    {
        if (args.length < 4 || args.length > 5)
        {
            usage();
        }

        String host = args[0];
        String ipBaseDeDonnees = args[1];
        String fichierODS = args[2];
        String repertoireString = args[3];

        String option = "";

        if (args.length == 5)
        {
            option = args[4];
        }

        File file = new File(fichierODS);

        if (!file.exists())
        {
            StringBuilder message = new StringBuilder("Le fichier ").append(file).append(" n'existe pas.");
            LOGGER.error(message.toString());
            System.exit(1);
        }
        
        //Test sur le repertoire de sortie
        File repertoire = new File(repertoireString);

        if (!repertoire.isDirectory())
        {
            StringBuilder message = new StringBuilder("Repertoire non present:").append(repertoireString);
            LOGGER.error(message.toString());
            System.exit(1);
        }
        
        //Récupérer le nom de l'OS
        String nomOS = file.getName().substring(0, 4);
        
        //Recupérer le mode du test Fonctionnel ou Performance 
        String mode = file.getName().substring(5, 9);
     
        // Initialisation des paramètres
        Parametres.setIpBaseDeDonnees(ipBaseDeDonnees);
        Parametres.setFichierODS(file);
        Parametres.setHost(host);
        Parametres.setRepertoire(repertoire);
        Parametres.setNomOS(nomOS);
        Parametres.setMode(mode);
        
        ContratApplicatif contrat = null;
        
        try
        {
            //Récupérer le contrat applicatif
            contrat = RecetteUtils.recupererContratApplicatif();
        }
        catch (RecetteFonctionnelleException e)
        {
            LOGGER.error(e.getMessage());
            System.exit(1);
        }
        
        Parametres.setContrat(contrat);
                
        try
        {
            if (file.getName().contains("async"))
            {
               LancementTestASynchro.lancer();
            }
            else
            {
                LancementTestSynchro.lancer();
            }            
        }
        catch (RecetteFonctionnelleException e)
        {
            LOGGER.error(e.getMessage());

            // mode verbeux
            if (option.equals("-v"))
            {
                LOGGER.error(e.getMessage(), e);
            }
        }

        LOGGER.info("");
    }

    public static void usage()
    {
        LOGGER.error("USAGE : program [adresse ip du serveur] [fichier à traiter] [repertoire de sortie] <-v> ");
        LOGGER.error(" -v : mode verbeux (parametre optionnel)");
        System.exit(2);
    }

}
