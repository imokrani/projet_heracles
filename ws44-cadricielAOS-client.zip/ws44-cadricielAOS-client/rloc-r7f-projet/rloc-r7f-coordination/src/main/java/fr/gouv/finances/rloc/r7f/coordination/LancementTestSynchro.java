package fr.gouv.finances.rloc.r7f.coordination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution.Restitution2OS08TestSuite;
import fr.gouv.finances.rloc.r7f.transverse.ContratApplicatif;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class LancementTestSynchro
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(LancementTestSynchro.class);

    public static void lancer() throws RecetteFonctionnelleException
    {
        int numeroOS = Integer.parseInt(Parametres.getNomOS().replace("OS", ""));

        LOGGER.info("Debut du traitement");
        LOGGER.info("nom du fichier: " + Parametres.getFichierODS().getName());

        ContratApplicatif contrat = Parametres.getContrat();

        TestSuite testSuite = null;

        switch (numeroOS)
        {
           
            case 8:
                if (contrat.getNomContrat().equals("contrat_rlocmas_restitution_1"))
                {
                   // testSuite = new RestitutionOS08TestSuite();
                }else if(contrat.getNomContrat().equals("contrat_rlocmas_restitution_2"))
                {
                    testSuite = new Restitution2OS08TestSuite();
                }
                else
                {
                   // testSuite = new Restitution3OS08TestSuite();
                }
                break;
            
            default:
                LOGGER.error("n° d'OS incorrecte");
                System.exit(1);
                break;
        }
        
        testSuite.lancer();
        
        LOGGER.info("Fin du traitement");

    }

}
