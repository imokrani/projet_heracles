package fr.gouv.finances.rloc.r7f.coordination;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.delta.DeltaTestAsync;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.CadricielTestAsync;
import fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution.async.Restitution2OS08TestSuiteAsync;
import fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution.async.performances.Restitution3OS08PERFTestSuiteAsync;
import fr.gouv.finances.rloc.r7f.transverse.ContratApplicatif;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class LancementTestASynchro
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(LancementTestASynchro.class);
    
    /** Mode de lancement de OS **/
    private static final String MODE_TEST_OS = "PERF";
    
    public static void lancer() throws RecetteFonctionnelleException
    {
        int numeroOS = Integer.parseInt(Parametres.getNomOS().replace("OS", ""));
        String mode = Parametres.getMode(); 

       LOGGER.info("Debut du traitement");
       LOGGER.info("nom du fichier: " + Parametres.getFichierODS().getName());
       
       ContratApplicatif contrat = Parametres.getContrat();

        System.out.println("Il sagit de testd e   "+mode);
        TestSuite testSuite = null;

        switch (numeroOS)
        {
            case 8:
                if(contrat.getNomContrat().equals("contrat_rlocmas_restitution_2"))
                {
                    testSuite = new Restitution2OS08TestSuiteAsync();
                }
                else
                {
                    if(mode.equals(MODE_TEST_OS))
                    {
                        
                        /** Il s'agit bien d'un  test de performance  **/
                       // testSuite = new Restitution3OS08PERFTestSuiteAsync(); 
                    }
                    else
                    {
                       // testSuite = new Restitution3OS08TestSuiteAsync();    
                    }
                }
                break;
             
            case 23:
                testSuite = new CadricielTestAsync();
                break; 
            case 15:
                testSuite = new DeltaTestAsync();
                break; 
            default:
                LOGGER.error("n° d'OS incorrecte");
                System.exit(1);
                break;
        }
        
        testSuite.lancer();
        
        LOGGER.info("Fin du traitement");

    }

}
