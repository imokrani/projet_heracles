package fr.gouv.finances.rloc.r7f.transverse.constantes;

import java.io.File;

import fr.gouv.finances.rloc.r7f.transverse.ContratApplicatif;

public class Parametres
{
    
    private static String host = "";
    
    private static String ipBaseDeDonnees = "";
    
    private static File fichierODS = null;
    
    private static File repertoire = null;
    
    private static String nomOS = "";

    private static ContratApplicatif contrat = null;
    
    private static String mode = ""; 
    
    public static String getHost()
    {
        return host;
    }

    public static void setHost(String host)
    {
        Parametres.host = host;
    }

    public static String getIpBaseDeDonnees()
    {
        return ipBaseDeDonnees;
    }

    public static void setIpBaseDeDonnees(String ipBaseDeDonnees)
    {
        Parametres.ipBaseDeDonnees = ipBaseDeDonnees;
    }

    public static File getRepertoire()
    {
        return repertoire;
    }

    public static void setRepertoire(File repertoire)
    {
        Parametres.repertoire = repertoire;
    }

    public static File getFichierODS()
    {
        return fichierODS;
    }

    public static void setFichierODS(File fichierODS)
    {
        Parametres.fichierODS = fichierODS;
    }
    

    public static String getNomOS()
    {
        return nomOS;
    }

    public static void setNomOS(String nomOS)
    {
        Parametres.nomOS = nomOS;
    }

    public static ContratApplicatif getContrat()
    {
        return contrat;
    }

    public static void setContrat(ContratApplicatif contrat)
    {
        Parametres.contrat = contrat;
    }

    public static String getMode()
    {
        return mode;
    }

    public static void setMode(String mode)
    {
        Parametres.mode = mode;
    }
}
