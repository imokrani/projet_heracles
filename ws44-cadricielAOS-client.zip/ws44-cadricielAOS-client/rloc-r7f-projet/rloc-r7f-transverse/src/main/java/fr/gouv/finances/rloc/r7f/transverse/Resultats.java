package fr.gouv.finances.rloc.r7f.transverse;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Resultats
{    
    /*
     * Liste des reponse sur tous les cas de test
     */
    private List<TreeMap<String, String>> liste = new ArrayList<TreeMap<String, String>>();

    /*
     * Reponse sur un cas de test
     */
    private TreeMap<String, String> resultat = null;

    /*
     * les arboresance extraite du XML (Pour l'ensemnle des cas de test)
     */
    private Set<String> arborescences = new TreeSet<String>();

    /**
     * Création d'un nouveau résultat dans la liste des résultats
     *
     * @param nomDuTest
     */
    public void creerNouveauResultat(String nomDuTest)
    {
        resultat = new TreeMap<String, String>();
        resultat.put("nomDuTest", nomDuTest);
        liste.add(resultat);
    }
    
    /**
     * Ajout d'une valeur dans le résultat courant  
     *
     * @param arborescence
     * @param valeur
     */
    public void ajouterValeur(String arborescence, String valeur)
    {
        resultat.put(arborescence, valeur);
        arborescences.add(arborescence);
    }
    
    public List<TreeMap<String, String>> getListe()
    {
        return liste;
    }

    public Set<String> getArborescences()
    {
        return arborescences;
    }
}
