package fr.gouv.finances.rloc.r7f.transverse.constantes;



public class ConstantesWSDL
{
    public static final String RECHERCHE = "RechercheLocalSynchroneInterface?wsdl";
    
    public static final String RESTITUTION = "RestitutionLocalSynchroneInterface?wsdl";
    
    public static final String RESTITUTION_TARIF_COEFFICIENT = "RestitutionTarifCoeffEvolLoyerSynchroneInterface?wsdl"; 
    
    public static final String RESTITUTION_ASYNC = "RestitutionLocalAsynchroneInterface?wsdl";
    
    public static final String DELTA = "DeltaLocalSynchroneInterface?wsdl";
    
    public static final String DELTA_ASYNC = "DeltaLocalAsynchroneInterface?wsdl";
    
    public static final String CREER_LOCAL_PROVISOIRE = "CreationProvisoireLocalSynchroneInterface?wsdl";
    
    public static final String CREER_LOCAL_FONCIER = "CreationFoncierLocalSynchroneInterface?wsdl";
    
    public static final String MODIFICATION = "ModificationLocalSynchroneInterface?wsdl";
    
    public static final String FIABILISATION = "FiabilisationLocalSynchroneInterface?wsdl";
    
    public static final String LIENS = "RestitutionDoublonSynchroneInterface?wsdl";
    
    public static final String RECHERCHE_IFP = "RechercherIFPSynchroneInterface?wsdl"; 
    
    public static final String RECHERCHE_IFP_ASYNC = "RechercherIFPAsynchroneInterface?wsdl"; 
    
    public static final String RESTITUTION_REVISION = "RestitutionRevLocalSynchroneInterface?wsdl"; 
    
    public static final String RESTITUTION_REVISION_ASYNC = "RestitutionRevLocalAsynchroneInterface?wsdl"; 
    
    public static final String RESTITUTION_TARIF_COEFFICIENT_ASYNC = "RestitutionTarifCoeffEvolLoyerAsynchroneInterface?wsdl"; 
    
    public static final String CALCULER_VL_SYNC = "CalculVLRevSynchroneInterface?wsdl";
    
    public static final String CALCULER_VL_ASYNC = "CalculVLRevAsynchroneInterface?wsdl";
    
    public static final String CADRICIEL_TEST_ASYNC = "GestionProjetsInterfaceAsynchrone?wsdl";
    
    public static final String CADRICIEL_DELTA_ASYNC = "DeltaLocalAsynchroneInterface?wsdl";
    
    
    
}

