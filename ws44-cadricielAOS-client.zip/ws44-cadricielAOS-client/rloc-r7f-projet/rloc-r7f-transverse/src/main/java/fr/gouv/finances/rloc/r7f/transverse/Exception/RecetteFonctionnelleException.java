package fr.gouv.finances.rloc.r7f.transverse.Exception;

public class RecetteFonctionnelleException extends Exception
{

    /**
    * serialVersionUID - long
    */
   private static final long serialVersionUID = 4218304585793608419L;

   /**
    * Crée une nouvelle instance de RecetteFonctionnelleException
    */
   public RecetteFonctionnelleException()
   {
       super();
   }

   /**
    * Crée une nouvelle instance de RecetteFonctionnelleException
    * 
    * @param message Le message détaillant exception
    */
   public RecetteFonctionnelleException(String message)
   {
       super(message);
   }

   /**
    * Crée une nouvelle instance de RecetteFonctionnelleException
    * 
    * @param cause L'exception à l'origine de cette exception
    */
   public RecetteFonctionnelleException(Throwable cause)
   {
       super(cause);
   }

   /**
    * Crée une nouvelle instance de RecetteFonctionnelleException
    * 
    * @param message Le message détaillant exception
    * @param cause L'exception à l'origine de cette exception
    */
   public RecetteFonctionnelleException(String message, Throwable cause)
   {
       super(message, cause);
   }
    
}
