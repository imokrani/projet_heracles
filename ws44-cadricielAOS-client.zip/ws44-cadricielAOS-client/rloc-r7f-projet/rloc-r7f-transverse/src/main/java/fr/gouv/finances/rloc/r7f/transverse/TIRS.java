package fr.gouv.finances.rloc.r7f.transverse;

public class TIRS
{

    private String departement; 
    private String nombreBloc; 
    private int tailleBloc; 
    private String typeTir;
    
    public TIRS()
    {
    }

    public String getDepartement()
    {
        return departement;
    }

    public void setDepartement(String departement)
    {
        this.departement = departement;
    }

    public String getNombreBloc()
    {
        return nombreBloc;
    }

    public void setNombreBloc(String nombreBloc)
    {
        this.nombreBloc = nombreBloc;
    }

    public int getTailleBloc()
    {
        return tailleBloc;
    }

    public void setTailleBloc(int tailleBloc)
    {
        this.tailleBloc = tailleBloc;
    }

    public String getTypeTir()
    {
        return typeTir;
    }

    public void setTypeTir(String typeTir)
    {
        this.typeTir = typeTir;
    }
}
