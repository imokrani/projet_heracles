package fr.gouv.finances.rloc.r7f.transverse;

public class ContratApplicatif
{
    private String application = "";
    
    private String nomContrat = "";
    
    private boolean isAsynchrone;

    public String getApplication()
    {
        return application;
    }

    public void setApplication(String application)
    {
        this.application = application;
    }

    public String getNomContrat()
    {
        return nomContrat;
    }

    public void setNomContrat(String nomContrat)
    {
        this.nomContrat = nomContrat;
    }

    public boolean isAsynchrone()
    {
        return isAsynchrone;
    }

    public void setAsynchrone(boolean isAsynchrone)
    {
        this.isAsynchrone = isAsynchrone;
    }
}
