package fr.gouv.finances.rloc.r7f.transverse.constantes;

public class Constantes
{
    public final static String PACKAGE_WSDL = "fr.gouv.impots.appli.rloc.service";
    
    public final static String PREFIX_TARGET_NAME_SPACE = "http://service.rloc.appli.impots.gouv.fr";

    public final static String SEPARATEUR = ";";
    
    public final static String ONGLET_REPONSE = "flux_reponse";
    
    public final static String ONGLET_ENTREE = "flux_entree";
    
    public final static String ONGLET_REPONSE_ATTENDU = new StringBuilder(ONGLET_REPONSE).append("_attendu").toString();
    
    public final static String ONGLET_CONTRAT = "contrat_applicatif";
}
