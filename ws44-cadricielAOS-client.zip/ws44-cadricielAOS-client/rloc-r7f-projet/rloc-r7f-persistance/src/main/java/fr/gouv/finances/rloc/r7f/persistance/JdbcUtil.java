package fr.gouv.finances.rloc.r7f.persistance;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class JdbcUtil
{
    // private static final Logger LOGGER = Logger.getLogger(JdbcUtil.class);

    private static Connection connection = null;

    public static void init() throws RecetteFonctionnelleException
    {

        Properties properties = new Properties();
        try
        {
            properties.load(Thread.currentThread()
                .getContextClassLoader().getResourceAsStream("database.properties"));
        }
        catch (FileNotFoundException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        catch (IOException e)
        {
            throw new RecetteFonctionnelleException(e);
        }

        StringBuilder url = new StringBuilder("jdbc:postgresql://").append(Parametres.getIpBaseDeDonnees()).append("/");

        String user = properties.getProperty("username");
        String pwd = properties.getProperty("password");
        String base = properties.getProperty("base");
        
        url.append(base);
        
        try
        {
            connection = DriverManager.getConnection(url.toString(), user, pwd);
        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
    }
    
    
    public static Connection currentConnection() throws RecetteFonctionnelleException
    {
        if (connection == null)
        {
            throw new RecetteFonctionnelleException("La connection a la base de données n'est pas initialisée.");
        }

        return connection;

    }

    public static void closeSession() throws RecetteFonctionnelleException
    {
        if (connection != null)
        {
            try
            {
                connection.close();
            }
            catch (SQLException e)
            {
                throw new RecetteFonctionnelleException(e);
            }
            connection = null;
        }
    }

}
