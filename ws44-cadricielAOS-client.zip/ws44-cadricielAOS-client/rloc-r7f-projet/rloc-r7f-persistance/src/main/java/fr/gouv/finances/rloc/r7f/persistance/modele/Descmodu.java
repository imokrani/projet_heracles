package fr.gouv.finances.rloc.r7f.persistance.modele;
import java.util.Date;

public class Descmodu
{

    private String cdaffectation = "";
    private Date anneebilan = null;
    private Date anneemvt = null;
    private String cdcausemvt = "";
    private Long montantimmo = null;
    private String devise = "";
    private Integer vldesc = null;
    private String cdtypevl = "";

    public Descmodu()
    {
    }

    public String getCdaffectation()
    {
        return this.cdaffectation;
    }

    public void setCdaffectation(String cdaffectation)
    {
        this.cdaffectation = cdaffectation;
    }

    public Date getAnneebilan()
    {
        return this.anneebilan;
    }

    public void setAnneebilan(Date anneebilan)
    {
        this.anneebilan = anneebilan;
    }

    public Date getAnneemvt()
    {
        return this.anneemvt;
    }

    public void setAnneemvt(Date anneemvt)
    {
        this.anneemvt = anneemvt;
    }

    public String getCdcausemvt()
    {
        return this.cdcausemvt;
    }

    public void setCdcausemvt(String cdcausemvt)
    {
        this.cdcausemvt = cdcausemvt;
    }

    public Long getMontantimmo()
    {
        return this.montantimmo;
    }

    public void setMontantimmo(Long montantimmo)
    {
        this.montantimmo = montantimmo;
    }

    public String getDevise()
    {
        return this.devise;
    }

    public void setDevise(String devise)
    {
        this.devise = devise;
    }

   
    public String getCdtypevl()
    {
        return this.cdtypevl;
    }

    public void setCdtypevl(String cdtypevl)
    {
        this.cdtypevl = cdtypevl;
    }

  
    public Integer getVldesc()
    {
        return vldesc;
    }

    public void setVldesc(Integer vldesc)
    {
        this.vldesc = vldesc;
    }

}
