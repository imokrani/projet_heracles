package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Desccbd;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class DescCBDDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(DescCBDDao.class);
    
    public boolean controlerDescCbd(Desccbd desc, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from imglocal img, desccbd descriptif ") 
                                .append("where img.idimglocal = descriptif.idimglocal and  img.idlocal = ? ");

        try
        {    
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
            
            if (!desc.getCdaffectation().equals(""))
            {
                query.append("and descriptif.cdaffectation = ? ");
                parametres.add(desc.getCdaffectation());
            }

            if (!desc.getCategorie().equals(""))
            {
                query.append("and descriptif.categorie = ? ");
                parametres.add(desc.getCategorie());
            }
            
            if (desc.getVldesc() != null)
            {
                query.append("and descriptif.vldesc = ? ");
                parametres.add(String.valueOf(desc.getVldesc()));
            }

            if (desc.getSurface() != null)
            {
                query.append("and descriptif.surface = ? ");
                parametres.add(String.valueOf(desc.getSurface()));
            }
            
            if (!desc.getOnsurfacereelle().equals(""))
            {
                query.append("and descriptif.onsurfaceReelle = ? ");
                parametres.add(desc.getOnsurfacereelle());
            }
            
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            
            
            int indexPS = 2; 
            
            if (!desc.getCdaffectation().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getCdaffectation());   
            }
            
            if (!desc.getCategorie().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getCategorie());   
            }

            if (desc.getVldesc() != null)
            {
                preparedStatement.setInt(indexPS++, desc.getVldesc());
            }

            if (desc.getSurface() != null)
            {
                preparedStatement.setInt(indexPS++, desc.getSurface());
            }
            
            if (!desc.getOnsurfacereelle().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getOnsurfacereelle());
            }
            
            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }
            
            resultats = preparedStatement.executeQuery();

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }
    
}
