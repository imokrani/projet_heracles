package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Adressetopo;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class AdresseTopoDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(Adressetopo.class);
    
    public boolean rechercherAdresseTopo(Adressetopo adresseTopo, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();

        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from adressetopo at, adrlocal al ")
        		                    .append("where al.idadressetopo = at.idadressetopo and al.idlocal = ? ");
        try
        {        
            
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
            
            if (!adresseTopo.getCddept().equals(""))
            {
                query.append("and at.cddept = ? ");
                parametres.add(adresseTopo.getCddept());
            }

            if (!adresseTopo.getCdcommune().equals(""))
            {
                query.append("and at.cdcommune = ? ");
                parametres.add(adresseTopo.getCdcommune());
            }

            if (!adresseTopo.getCdvoie().equals(""))
            {
                query.append("and at.cdvoie = ? ");
                parametres.add(adresseTopo.getCdvoie());
            }

            if (!adresseTopo.getNovoirie().equals(""))
            {
                query.append("and at.novoirie = ? ");
                parametres.add(adresseTopo.getNovoirie());
            }

            if (!adresseTopo.getIndrep().equals(""))
            {
                query.append("and at.indrep = ?");
                parametres.add(adresseTopo.getIndrep());
            }
            
            if (!adresseTopo.getCdcommuneifp().equals(""))
            {
                query.append("and at.cdcommuneifp = ?");
                parametres.add(adresseTopo.getCdcommuneifp());
            }
            

            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            
            int indexPS = 2; 
                        
            
            if (!adresseTopo.getCddept().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getCddept());
            }

            if (!adresseTopo.getCdcommune().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getCdcommune());
            }

            if (!adresseTopo.getCdvoie().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getCdvoie());
            }

            if (!adresseTopo.getNovoirie().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getNovoirie());
            }

            if (!adresseTopo.getIndrep().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getIndrep());
            }
            
            if (!adresseTopo.getCdcommuneifp().equals(""))
            {
                preparedStatement.setString(indexPS++, adresseTopo.getCdcommuneifp());
            }

            resultats = preparedStatement.executeQuery();
            
            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }
           
            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        
        return isValide; 
    }
    
}
