package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Imglocal;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class ImgLocalDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(ImgLocalDao.class);
    
    public boolean rechercherImgLocal(Imglocal imgLocal, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
      
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from imglocal where idlocal = ? ");

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        try
        {    
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
                   
            if (imgLocal.getDteffet() != null)
            {
                query.append("and dteffet = ? ");
                parametres.add(format.format(imgLocal.getDteffet()));
            }
            
            if (!imgLocal.getCdevaluation().equals(""))
            {
                query.append("and cdevaluation = ? ");
                parametres.add(imgLocal.getCdevaluation());
            }

            if (!imgLocal.getCdnature().equals(""))
            {
                query.append("and cdnature = ? ");
                parametres.add(imgLocal.getCdnature());
            }
           
            if (!imgLocal.getCdchangement().equals(""))
            {
                query.append("and cdchangement = ? ");
                parametres.add(imgLocal.getCdchangement());
            }
            
            if (!imgLocal.getCdmotifcreation().equals(""))
            {
                query.append("and cdmotifcreation = ? ");
                parametres.add(imgLocal.getCdmotifcreation());
            }
            
            if (!imgLocal.getTypelocal().equals(""))
            {
                query.append("and typelocal = ? ");
                parametres.add(imgLocal.getTypelocal());
            }
            
            if (!imgLocal.getCdconstparticuliere().equals(""))
            {
                query.append("and cdconstparticuliere = ? ");
                parametres.add(imgLocal.getCdconstparticuliere());
            }
            
            if (!imgLocal.getCategorieloi48().equals(""))
            {
                query.append("and categorieloi48 = ? ");
                parametres.add(imgLocal.getCategorieloi48());
            }
            
            if (imgLocal.getLoyerloi48() != null)
            {
                query.append("and loyerloi48 = ? ");
                parametres.add(String.valueOf(imgLocal.getLoyerloi48()));
            }

            if (!imgLocal.getTypedesc().equals(""))
            {
                query.append("and typedesc = ? ");
                parametres.add(imgLocal.getTypedesc());
            }
            
            if (!imgLocal.getCdoccupationlocal().equals(""))
            {
                query.append("and cdoccupationlocal = ? ");
                parametres.add(imgLocal.getCdoccupationlocal());
            }
            
            if (!imgLocal.getOnparking().equals(""))
            {
                query.append("and onparking = ? ");
                parametres.add(imgLocal.getOnparking());
            }
            
            if (!imgLocal.getOnsoussol().equals(""))
            {
                query.append("and onsoussol = ? ");
                parametres.add(imgLocal.getOnsoussol());
            }
            
            if (!imgLocal.getOntsbcs().equals(""))
            {
                query.append("and ontsbcs = ? ");
                parametres.add(imgLocal.getOntsbcs());
            }
            
            if (imgLocal.getNbpev() != null)
            {
                query.append("and nbpev = ? ");
                parametres.add(String.valueOf(imgLocal.getNbpev()));
            }

            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            
            
            int indexPS = 2; 
            
            if (imgLocal.getDteffet() != null)
            {
                preparedStatement.setDate(indexPS++, new java.sql.Date(imgLocal.getDteffet().getTime()));
                
            }

            if (!imgLocal.getCdevaluation().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdevaluation());
            }

            if (!imgLocal.getCdnature().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdnature());
            }
            
            if (!imgLocal.getCdchangement().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdchangement());
            }
            

            if (!imgLocal.getCdmotifcreation().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdmotifcreation());
            }
            
            if (!imgLocal.getTypelocal().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getTypelocal());
            }
            
            if (!imgLocal.getCdconstparticuliere().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdconstparticuliere());
            }
            
            if (!imgLocal.getCategorieloi48().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCategorieloi48());
            }
            
            if (imgLocal.getLoyerloi48() != null)
            {
                preparedStatement.setInt(indexPS++, imgLocal.getLoyerloi48());
            }

            if (!imgLocal.getTypedesc().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getTypedesc());
            }
            
            if (!imgLocal.getCdoccupationlocal().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getCdoccupationlocal());
            }
            
            if (!imgLocal.getOnparking().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getOnparking());
            }
            
            if (!imgLocal.getOnsoussol().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getOnsoussol());
            }
            
            if (!imgLocal.getOntsbcs().equals(""))
            {
                preparedStatement.setString(indexPS++, imgLocal.getOntsbcs());
            }
            
            if (imgLocal.getNbpev() != null)
            {
                preparedStatement.setInt(indexPS++, imgLocal.getNbpev());
            }
            
            resultats = preparedStatement.executeQuery();

            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }
            
            
            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        
        return isValide;
    }
}
