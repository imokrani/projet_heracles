package fr.gouv.finances.rloc.r7f.persistance.modele;

public class Lot
{    
    private String nolot = "";

    public Lot(String nolot)
    {
        this.nolot = nolot;
    }

    public String getNolot()
    {
        return this.nolot;
    }

    public void setNolot(String nolot)
    {
        this.nolot = nolot;
    }
}
