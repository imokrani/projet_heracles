package fr.gouv.finances.rloc.r7f.persistance.modele;

public class Desccbd 
{

    private Integer vldesc = null;

    private String cdaffectation = "";

    private String categorie = "";

    private Integer nbelements = null;

    private Integer surface = null;

    private String onsurfacereelle = "";

    public Desccbd()
    {
    }

    public String getCdaffectation()
    {
        return this.cdaffectation;
    }

    public void setCdaffectation(String cdaffectation)
    {
        this.cdaffectation = cdaffectation;
    }

    public Integer getNbelements()
    {
        return this.nbelements;
    }

    public void setNbelements(Integer nbelements)
    {
        this.nbelements = nbelements;
    }

    public String getCategorie()
    {
        return categorie;
    }

    public void setCategorie(String categorie)
    {
        this.categorie = categorie;
    }

    public Integer getVldesc()
    {
        return vldesc;
    }

    public void setVldesc(Integer vldesc)
    {
        this.vldesc = vldesc;
    }

    public Integer getSurface()
    {
        return surface;
    }

    public void setSurface(Integer surface)
    {
        this.surface = surface;
    }

    public String getOnsurfacereelle()
    {
        return onsurfacereelle;
    }

    public void setOnsurfacereelle(String onsurfacereelle)
    {
        this.onsurfacereelle = onsurfacereelle;
    }
}
