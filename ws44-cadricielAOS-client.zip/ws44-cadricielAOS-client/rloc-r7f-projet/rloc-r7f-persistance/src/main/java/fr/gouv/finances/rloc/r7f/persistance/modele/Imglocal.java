package fr.gouv.finances.rloc.r7f.persistance.modele;

import java.util.Date;

public class Imglocal 
{
    private String invariant = "";
    private String cdevaluation = "";
    private String cdnature = "";
    private String cdmotifcreation = "";   
    private String cdchangement = "";
    private Date dteffet = null;
    private Date dtinvalid = null;
    private Date dtmaj = null ;
    private String typelocal = "";
    private String cdconstparticuliere = "";
    private String categorieloi48 = "";
    private Integer loyerloi48 = null;
    private String typedesc = "";
    private String cdoccupationlocal = "";
    private String onparking = "";
    private String onsoussol = "";
    private String ontsbcs = "";
    private Integer nbpev = null;

    public String getInvariant()
    {
        return this.invariant;
    }

    public void setInvariant(String invariant)
    {
        this.invariant = invariant;
    }   
  
    public String getCdevaluation()
    {
        return this.cdevaluation;
    }

    public void setCdevaluation(String cdevaluation)
    {
        this.cdevaluation = cdevaluation;
    }

    public String getCdnature()
    {
        return this.cdnature;
    }

    public void setCdnature(String cdnature)
    {
        this.cdnature = cdnature;
    }
   

    public String getCdchangement()
    {
        return this.cdchangement;
    }

    public void setCdchangement(String cdchangement)
    {
        this.cdchangement = cdchangement;
    }

    public Date getDteffet()
    {
        return this.dteffet;
    }

    public void setDteffet(Date dteffet)
    {
        this.dteffet = dteffet;
    }

    public Date getDtinvalid()
    {
        return this.dtinvalid;
    }

    public void setDtinvalid(Date dtinvalid)
    {
        this.dtinvalid = dtinvalid;
    }

    public Date getDtmaj()
    {
        return this.dtmaj;
    }

    public void setDtmaj(Date dtmaj)
    {
        this.dtmaj = dtmaj;
    }


    public String getTypelocal()
    {
        return this.typelocal;
    }

    public void setTypelocal(String typelocal)
    {
        this.typelocal = typelocal;
    }

    public String getCdconstparticuliere()
    {
        return this.cdconstparticuliere;
    }

    public void setCdconstparticuliere(String cdconstparticuliere)
    {
        this.cdconstparticuliere = cdconstparticuliere;
    }

    public String getCategorieloi48()
    {
        return this.categorieloi48;
    }

    public void setCategorieloi48(String categorieloi48)
    {
        this.categorieloi48 = categorieloi48;
    }

    public Integer getLoyerloi48()
    {
        return this.loyerloi48;
    }

    public void setLoyerloi48(Integer loyerloi48)
    {
        this.loyerloi48 = loyerloi48;
    }

    public String getTypedesc()
    {
        return this.typedesc;
    }

    public void setTypedesc(String typedesc)
    {
        this.typedesc = typedesc;
    }


    public String getOnparking()
    {
        return onparking;
    }

    public void setOnparking(String onparking)
    {
        this.onparking = onparking;
    }

    public String getOnsoussol()
    {
        return onsoussol;
    }

    public void setOnsoussol(String onsoussol)
    {
        this.onsoussol = onsoussol;
    }

    public String getOntsbcs()
    {
        return ontsbcs;
    }

    public void setOntsbcs(String ontsbcs)
    {
        this.ontsbcs = ontsbcs;
    }

   

    public Integer getNbpev()
    {
        return nbpev;
    }

    public void setNbpev(Integer nbpev)
    {
        this.nbpev = nbpev;
    }

    public String getCdmotifcreation()
    {
        return cdmotifcreation;
    }

    public void setCdmotifcreation(String cdmotifcreation)
    {
        this.cdmotifcreation = cdmotifcreation;
    }

    public String getCdoccupationlocal()
    {
        return cdoccupationlocal;
    }

    public void setCdoccupationlocal(String cdoccupationlocal)
    {
        this.cdoccupationlocal = cdoccupationlocal;
    }    
}
