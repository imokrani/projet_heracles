package fr.gouv.finances.rloc.r7f.persistance.utilitaire;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RecetteUtils
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(RecetteUtils.class);
    
    
       
    public static void afficherRequete(StringBuilder query, List<String> parametres)
    {        
        // découper le requete            
        List<String> requeteDecoupee = Arrays.asList(query.toString().split("\\?"));

        StringBuilder requeteAfficher = new StringBuilder();
        
        for (int i = 0; i < requeteDecoupee.size(); i++)
        {
                if(requeteDecoupee.get(i).equals(" "))
                {
                    break;
                }
            
                requeteAfficher.append(requeteDecoupee.get(i)).append("'").append(parametres.get(i)).append("'");
        } 
        
        LOGGER.debug(new StringBuilder("query= ").append(requeteAfficher).toString());       
    }   
    
}
