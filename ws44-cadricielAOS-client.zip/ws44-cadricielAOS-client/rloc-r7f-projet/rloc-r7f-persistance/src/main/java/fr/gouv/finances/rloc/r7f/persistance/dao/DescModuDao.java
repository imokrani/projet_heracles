package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Descmodu;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class DescModuDao
{

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(DescModuDao.class);
    
    public boolean controlerDescModu(Descmodu desc, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from imglocal img, descmodu descriptif ") 
                                .append("where img.idimglocal = descriptif.idimglocal and  img.idlocal = ? ");

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        
        try
        {    
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
            
            if (!desc.getCdaffectation().equals(""))
            {
                query.append("and descriptif.cdaffectation = ? ");
                parametres.add(desc.getCdaffectation());
            }

            if (desc.getVldesc() != null)
            {
                query.append("and descriptif.vldesc = ? ");
                parametres.add(String.valueOf(desc.getVldesc()));
            }

            if (desc.getAnneebilan() != null)
            {
                query.append("and descriptif.anneebilan = ? ");
                parametres.add(format.format(desc.getAnneebilan()));
            }
            
            if (desc.getAnneemvt() != null)
            {
                query.append("and descriptif.anneemvt = ? ");
                parametres.add(format.format(desc.getAnneemvt()));
            }
            
            if (!desc.getCdcausemvt().equals(""))
            {
                query.append("and descriptif.cdcausemvt = ? ");
                parametres.add(String.valueOf(desc.getCdcausemvt()));
            }
            
            if (desc.getMontantimmo() != null)
            {
                query.append("and descriptif.montantimmo = ? ");
                parametres.add(String.valueOf(desc.getMontantimmo()));
            }
            
            if (!desc.getDevise().equals(""))
            {
                query.append("and descriptif.devise = ? ");
                parametres.add(String.valueOf(desc.getDevise()));
            }
            
            if (!desc.getCdtypevl().equals(""))
            {
                query.append("and descriptif.cdtypevl = ? ");
                parametres.add(String.valueOf(desc.getCdtypevl()));
            }
       
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            
            int indexPS = 2; 
            
            if (!desc.getCdaffectation().equals(""))
            {
                preparedStatement.setString(indexPS++,desc.getCdaffectation());   
            }

            if (desc.getVldesc() != null)
            {
                preparedStatement.setInt(indexPS++, desc.getVldesc());
            }

            if (desc.getAnneebilan() != null)
            {     
                preparedStatement.setDate(indexPS++, new java.sql.Date(desc.getAnneebilan().getTime()));
            }
            
            if (desc.getAnneemvt() != null)
            {
                preparedStatement.setDate(indexPS++, new java.sql.Date(desc.getAnneemvt().getTime()));
            }
            
            if (!desc.getCdcausemvt().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getCdcausemvt());
            }
            
            if (desc.getMontantimmo() != null)
            {
                preparedStatement.setLong(indexPS++, desc.getMontantimmo());
            }
            
            if (!desc.getDevise().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getDevise());
            }
            
            if (!desc.getCdtypevl().equals(""))
            {
                preparedStatement.setString(indexPS++, desc.getCdtypevl());
            }
            
            resultats = preparedStatement.executeQuery();
            
            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }
    
}
