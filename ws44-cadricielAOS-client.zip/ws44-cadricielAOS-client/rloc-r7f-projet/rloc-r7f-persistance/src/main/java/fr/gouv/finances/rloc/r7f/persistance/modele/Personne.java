package fr.gouv.finances.rloc.r7f.persistance.modele;


public class Personne 
{
    private String itip;

    public Personne()
    {
        
    }

    public Personne(String itip)
    {
        this.itip = itip;
    }

    public String getItip()
    {
        return this.itip;
    }

    public void setItip(String itip)
    {
        this.itip = itip;
    }
}
