package fr.gouv.finances.rloc.r7f.persistance.modele;





public class Adressetopo
{
    private String cddept = ""; 
    private String cdcommune = "";    
    private String cdvoie = "";
    private String novoirie = "";     
    private String indrep = "";
    private String cdcommuneifp = "";
    
    public Adressetopo()
    {
        
    }  
    
    public String getCddept()
    {
        return cddept;
    }

    public void setCddept(String cddept)
    {
        this.cddept = cddept;
    }

    public String getCdcommune()
    {
        return cdcommune;
    }

    public void setCdcommune(String cdcommune)
    {
        this.cdcommune = cdcommune;
    }

    public String getCdvoie()
    {
        return cdvoie;
    }

    public void setCdvoie(String cdvoie)
    {
        this.cdvoie = cdvoie;
    }

   
    public String getIndrep()
    {
        return indrep;
    }


    public void setIndrep(String indrep)
    {
        this.indrep = indrep;
    }

    public String getCdcommuneifp()
    {
        return cdcommuneifp;
    }

    public void setCdcommuneifp(String cdcommuneifp)
    {
        this.cdcommuneifp = cdcommuneifp;
    }
   
    public String getNovoirie()
    {
        return novoirie;
    }
    public void setNovoirie(String novoirie)
    {
        this.novoirie = novoirie;
    }
    
}
