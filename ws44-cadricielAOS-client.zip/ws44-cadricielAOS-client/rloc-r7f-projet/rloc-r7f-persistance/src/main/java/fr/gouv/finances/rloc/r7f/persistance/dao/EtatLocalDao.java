package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class EtatLocalDao
{

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(EtatLocalDao.class);
    
    public boolean controlerEtatLocal(String idLocal,String cdEtat, Date dtEffet) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from etatLocal where ") 
                                .append("idlocal = ? and cdetat = ? and dteffet = ? ");
            
        try
        {   
            
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            preparedStatement.setString(2, cdEtat);
            
            java.sql.Date date = new java.sql.Date(dtEffet.getTime());
            preparedStatement.setDate(3,date);  
            
            if(LOGGER.isDebugEnabled())
            {
                List<String> parametres = new ArrayList<String>();
                parametres.add(idLocal);
                parametres.add(cdEtat);
                
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                parametres.add(format.format(date));
                
               RecetteUtils.afficherRequete(query, parametres);
            }
            
            resultats = preparedStatement.executeQuery();
            

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }
    
    
    public boolean controlerEtatLocalInvalide(String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from etatLocal where ") 
                                .append("idlocal = ? and dtinvalid is not null ");
        
        try
        {   
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);               
            
            if(LOGGER.isDebugEnabled())
            {
                LOGGER.debug(new StringBuilder("query= ").append(query).toString());
            }
            
            resultats = preparedStatement.executeQuery();
            

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }
    
}
