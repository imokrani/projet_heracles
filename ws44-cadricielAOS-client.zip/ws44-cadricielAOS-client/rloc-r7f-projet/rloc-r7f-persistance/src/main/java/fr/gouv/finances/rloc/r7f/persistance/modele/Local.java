package fr.gouv.finances.rloc.r7f.persistance.modele;

import java.util.Date;

public class Local 
{
   
    private Date dtcrearloc = null;
    private String cdmapcre = "";
    private String invariantorig = "";
    private String sagesservicecre = "";
    private String idagentcre = "";
    private String nomproprietaire = "";
    private String blocnote = "";
  
    public Local()
    {
    }

    public Date getDtcrearloc()
    {
        return this.dtcrearloc;
    }

    public void setDtcrearloc(Date dtcrearloc)
    {
        this.dtcrearloc = dtcrearloc;
    }

    public String getCdmapcre()
    {
        return this.cdmapcre;
    }

    public void setCdmapcre(String cdmapcre)
    {
        this.cdmapcre = cdmapcre;
    }

    public String getInvariantorig()
    {
        return this.invariantorig;
    }

    public void setInvariantorig(String invariantorig)
    {
        this.invariantorig = invariantorig;
    }

    public String getSagesservicecre()
    {
        return this.sagesservicecre;
    }

    public void setSagesservicecre(String sagesservicecre)
    {
        this.sagesservicecre = sagesservicecre;
    }

    public String getNomproprietaire()
    {
        return this.nomproprietaire;
    }

    public void setNomproprietaire(String nomproprietaire)
    {
        this.nomproprietaire = nomproprietaire;
    }

    public String getBlocnote()
    {
        return this.blocnote;
    }

    public void setBlocnote(String blocnote)
    {
        this.blocnote = blocnote;
    }

    public String getIdagentcre()
    {
        return idagentcre;
    }

    public void setIdagentcre(String idagentcre)
    {
        this.idagentcre = idagentcre;
    }
  
}
