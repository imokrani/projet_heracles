package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Identifiantcadastral;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class IdentifiantCadastralDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(IdentifiantCadastralDao.class);
    
    public boolean rechercherIdentifiantCadastral(Identifiantcadastral idCadastral, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
      
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from identifiantCadastral where idlocal = ? ");

        try
        {      
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
            
            if (!idCadastral.getCddept().equals(""))
            {
                query.append("and cddept = ? ");
                parametres.add(idCadastral.getCddept());
            }
           
            if (!idCadastral.getCdcommunecad().equals(""))
            {
                query.append("and cdcommunecad = ? ");
                parametres.add(idCadastral.getCdcommunecad());
            }
            
            if (!idCadastral.getCdprefix().equals(""))
            {
                query.append("and cdprefix = ? ");
                parametres.add(idCadastral.getCdprefix());
            }
            
            if (!idCadastral.getCdsection().equals(""))
            {
                query.append("and cdsection = ? ");
                parametres.add(idCadastral.getCdsection());
            }
            
            if (!idCadastral.getNoplan().equals(""))
            {
                query.append("and noplan = ? ");
                parametres.add(idCadastral.getNoplan());
            }
            
            if (!idCadastral.getNobatiment().equals(""))
            {
                query.append("and nobatiment = ? ");
                parametres.add(idCadastral.getNobatiment());
            }
            
            if (!idCadastral.getNoescalier().equals(""))
            {
                query.append("and noescalier = ? ");
                parametres.add(idCadastral.getNoescalier());
            }
            
            if (!idCadastral.getNoetage().equals(""))
            {
                query.append("and noetage = ? ");
                parametres.add(idCadastral.getNoetage());
            }
            
            if (!idCadastral.getNoporte().equals(""))
            {
                query.append("and noporte = ? ");
                parametres.add(idCadastral.getNoporte());
            }
            
            if (idCadastral.getNbniveaux() != null)
            {
                query.append("and nbniveaux = ? ");
                parametres.add(String.valueOf(idCadastral.getNbniveaux()));
            }
           

            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            
            
            int indexPS = 2; 

            if (!idCadastral.getCddept().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getCddept());
            }
           
            if (!idCadastral.getCdcommunecad().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getCdcommunecad());
            }
            
            if (!idCadastral.getCdprefix().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getCdprefix());
            }
            
            if (!idCadastral.getCdsection().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getCdsection());
            }
            
            if (!idCadastral.getNoplan().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getNoplan());
            }
            
            if (!idCadastral.getNobatiment().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getNobatiment());
            }
            
            if (!idCadastral.getNoescalier().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getNoescalier());
            }
            
            if (!idCadastral.getNoetage().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getNoetage());
            }
            
            if (!idCadastral.getNoporte().equals(""))
            {
                preparedStatement.setString(indexPS++, idCadastral.getNoporte());
            }
            
            if (idCadastral.getNbniveaux() != null)
            {
                preparedStatement.setInt(indexPS++, idCadastral.getNbniveaux());
            }
            
            resultats = preparedStatement.executeQuery();

            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }
            
            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        
        return isValide;
    }
    
}
