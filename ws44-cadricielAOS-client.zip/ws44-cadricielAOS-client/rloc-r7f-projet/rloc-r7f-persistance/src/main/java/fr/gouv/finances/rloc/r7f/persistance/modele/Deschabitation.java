package fr.gouv.finances.rloc.r7f.persistance.modele;


public class Deschabitation 
{
    private String cdaffectation = "";

    private Integer nbpiecesppales = null;

    private Integer surface = null;

    private Integer vldesc = null;

    private String categoriehab = "";

    private String cddeschab = "";

    public Deschabitation()
    {
    }
    
    public String getCdaffectation()
    {
        return this.cdaffectation;
    }

    public void setCdaffectation(String cdaffectation)
    {
        this.cdaffectation = cdaffectation;
    }

    public Integer getNbpiecesppales()
    {
        return this.nbpiecesppales;
    }

    public void setNbpiecesppales(Integer nbpiecesppales)
    {
        this.nbpiecesppales = nbpiecesppales;
    }

    public String getCategoriehab()
    {
        return this.categoriehab;
    }

    public void setCategoriehab(String categoriehab)
    {
        this.categoriehab = categoriehab;
    }

    public String getCddeschab()
    {
        return this.cddeschab;
    }

    public void setCddeschab(String cddeschab)
    {
        this.cddeschab = cddeschab;
    }

    public Integer getVldesc()
    {
        return vldesc;
    }

    public void setVldesc(Integer vldesc)
    {
        this.vldesc = vldesc;
    }

    public Integer getSurface()
    {
        return surface;
    }

    public void setSurface(Integer surface)
    {
        this.surface = surface;
    }

}
