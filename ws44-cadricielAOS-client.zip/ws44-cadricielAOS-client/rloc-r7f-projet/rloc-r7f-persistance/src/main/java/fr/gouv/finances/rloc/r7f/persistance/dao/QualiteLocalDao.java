package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class QualiteLocalDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(QualiteLocalDao.class);
    
    public boolean controlerQualiteLocal(String idLocal,String cdQualite) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from qualitelocal where ") 
                                .append("idlocal = ? and cdqualite = ?");
            
        try
        {   
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);    
            preparedStatement.setString(2, cdQualite);
           
            if(LOGGER.isDebugEnabled())
            {
                List<String> parametres = new ArrayList<String>();
                parametres.add(idLocal);
                parametres.add(cdQualite);
                
                RecetteUtils.afficherRequete(query, parametres);
            }
            
            resultats = preparedStatement.executeQuery();
            

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }
    
    
    public boolean controlerQualiteLocalInvalide(String idLocal, String cdQualite) throws RecetteFonctionnelleException
    {
        boolean isValide = false;
        
        Connection con = JdbcUtil.currentConnection();
       
        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from qualitelocal where ") 
                                .append("idlocal = ? and cdqualite = ? and dtinvalid is not null");
        
        try
        {   
            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);
            preparedStatement.setString(2, cdQualite);
            
            if(LOGGER.isDebugEnabled())
            {
                List<String> parametres = new ArrayList<String>();
                parametres.add(idLocal);
                parametres.add(cdQualite);
                
                RecetteUtils.afficherRequete(query, parametres);
            }
            
            resultats = preparedStatement.executeQuery();
            

            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        
        return isValide;
    }

}
