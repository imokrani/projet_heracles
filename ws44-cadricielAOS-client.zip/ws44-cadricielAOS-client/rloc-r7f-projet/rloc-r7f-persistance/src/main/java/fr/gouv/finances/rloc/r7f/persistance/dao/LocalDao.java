package fr.gouv.finances.rloc.r7f.persistance.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.persistance.JdbcUtil;
import fr.gouv.finances.rloc.r7f.persistance.modele.Local;
import fr.gouv.finances.rloc.r7f.persistance.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;

public class LocalDao
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(LocalDao.class);

    public boolean rechercherLocal(Local local, String idLocal) throws RecetteFonctionnelleException
    {
        boolean isValide = false;

        Connection con = JdbcUtil.currentConnection();

        ResultSet resultats = null;
        StringBuilder query = new StringBuilder("select count(*) from local where idlocal = ? ");

        try
        {
            List<String> parametres = new ArrayList<String>();
            parametres.add(idLocal);
            
            if (!local.getCdmapcre().equals(""))
            {
                query.append("and cdmapcre = ? ");
                parametres.add(local.getCdmapcre());
            }

            if (!local.getInvariantorig().equals(""))
            {
                query.append("and invariantorig = ? ");
                parametres.add(local.getInvariantorig());
            }

            if (!local.getSagesservicecre().equals(""))
            {
                query.append("and sagesserviceCre = ? ");
                parametres.add(local.getSagesservicecre());
            }

            if (!local.getIdagentcre().equals(""))
            {
                query.append("and idagentCre = ? ");
                parametres.add(local.getIdagentcre());
            }

            if (!local.getNomproprietaire().equals(""))
            {
                query.append("and nomproprietaire = ? ");
                parametres.add(local.getNomproprietaire());
            }

            if (!local.getBlocnote().equals(""))
            {
                query.append("and blocnote = ?");
                parametres.add(local.getBlocnote());
            }

            PreparedStatement preparedStatement = con.prepareStatement(query.toString());
            preparedStatement.setString(1, idLocal);

            int indexPS = 2;
            
            if (!local.getCdmapcre().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getCdmapcre());

            }

            if (!local.getInvariantorig().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getInvariantorig());
            }

            if (!local.getSagesservicecre().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getSagesservicecre());
            }

            if (!local.getIdagentcre().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getIdagentcre());
            }

            if (!local.getNomproprietaire().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getNomproprietaire());
            }

            if (!local.getBlocnote().equals(""))
            {
                preparedStatement.setString(indexPS++, local.getBlocnote());
            }

            resultats = preparedStatement.executeQuery();
            
            if(LOGGER.isDebugEnabled())
            {
               RecetteUtils.afficherRequete(query, parametres);
            }
            
            boolean encore = resultats.next();
            while (encore)
            {
                if (resultats.getInt(1) == 1)
                {
                    isValide = true;
                }
                encore = resultats.next();
            }

        }
        catch (SQLException e)
        {
            throw new RecetteFonctionnelleException(e);
        }

        return isValide;
    }
}
