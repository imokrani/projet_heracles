package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.GestionProjetsInterfaceAsynchroneImpl;
import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.TechDysfonctionnementException;
import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.TechIndisponibiliteException;
import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.TechProtocolaireException;
import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.ov.AvancementValeur;
import fr.gouv.finances.aos.mas.service.stubs.projets.asynchrone.ov.ServiceAsynchroneValeur;
import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.ProjetRequeteDto;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.ProjetsRequeteAsyncDto;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.ConstantesWSDL;
import fr.gouv.impots.appli.commun.frameworks.gestionressources.GestionnaireRessources;
import fr.gouv.impots.appli.commun.frameworks.gestionressources.transverse.RessourceFactoryJndiImpl;

public class CadricielTestAsync  extends TestSuite
{
    private GestionProjetsInterfaceAsynchroneImpl assitant ; 
    
    public CadricielTestAsync()
    {
        super(); 
    }
    
    @Override
    public void lancer() throws RecetteFonctionnelleException
    {
        assitant = creerService("GestionProjetsInterfaceAsynchrone", ConstantesWSDL.CADRICIEL_TEST_ASYNC)
            .getPort(GestionProjetsInterfaceAsynchroneImpl.class);
        RecetteUtils.ajouterEnteteHTTP(assitant);
        
        GestionnaireRessources.setFactory(new RessourceFactoryJndiImpl());
        try
        {
            /** Récupération d'un IEIS **/
            byte[] ieis = assitant.obtenirIEIS();
            ServiceAsynchroneValeur serviceAsynchroneValeur = new ServiceAsynchroneValeur(); 
            serviceAsynchroneValeur.setIeis(ieis);
            /** Préparation de la requete **/
            ProjetRequeteDto req1 = new ProjetRequeteDto();
            req1.setNum(0);
            req1.setBureau("SI-1C");
            req1.setDivision("DTT");
            req1.setId("c3a80c11dbd711e5639a274e82ce6f97");
            req1.setNom("Projet_0");
            ProjetsRequeteAsyncDto listeReq = new ProjetsRequeteAsyncDto();
            listeReq.getProjetRequeteDtos().add(req1);
            File fileTemp = null;
            DataHandler dataHandlerRequete = null; 
            try
            {
                fileTemp = File.createTempFile("TestCadricielProjet", ".xml");
                JAXBContext context = JAXBContext.newInstance(ProjetRequeteDto.class); 
                Marshaller marshaller = context.createMarshaller(); 
                marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
                marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
                marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                FileOutputStream outputStream =new FileOutputStream(fileTemp);
                XMLStreamWriter xmlWriter = XMLOutputFactory.newInstance().createXMLStreamWriter(outputStream, "UTF-8"); 
                xmlWriter.writeStartDocument("UTF-8", "1.0");
                xmlWriter.writeStartElement("projetsRequeteAsyncDto");
                for(ProjetRequeteDto projet: listeReq.getProjetRequeteDtos())
                {
                    JAXBElement<ProjetRequeteDto> element = new JAXBElement<ProjetRequeteDto>(QName.valueOf("projetRequeteDtos"), ProjetRequeteDto.class, projet); 
                    marshaller.marshal(element, xmlWriter);
                    xmlWriter.flush();
                }
                xmlWriter.writeEndDocument();
                xmlWriter.close();             
                outputStream.close();
                FileDataSource fileDataSource = new FileDataSource(fileTemp); 
                dataHandlerRequete = new DataHandler(fileDataSource);
            }
            catch (IOException | JAXBException | XMLStreamException | FactoryConfigurationError e1)
            {
                //Erreur de génération de la pièce jointe
            }
            
            /** Appel du service **/
            assitant.creerProjet(serviceAsynchroneValeur, dataHandlerRequete);
            
            boolean attente = true;
//            while (attente) {
//                try
//                {
//                    Thread.sleep(1000);
//                }
//                catch (InterruptedException e)
//                {
//                }
//                
//                AvancementValeur avancement = assitant.obtenirAvancement(serviceAsynchroneValeur);
//                System.out.println(avancement.getInfoAvancement().getStatut());
//                if (avancement.getInfoAvancement().getStatut() == 5) {
//                    attente = false;
//                }
//            }
            AvancementValeur avancementValeur = null;
            do
            {   
                try
                {
                    Thread.sleep(5000);
                }
                catch (InterruptedException e)
                {
                    throw new RecetteFonctionnelleException(e);
                }
                 avancementValeur = assitant.obtenirAvancement(serviceAsynchroneValeur);
                long finAppelAvan = System.currentTimeMillis();
                System.out.println("obtenirAvancement  Durée exécution ");
            }
            // la valeur "4" du statut de l'IEIS indique que le traitement est en cours de réalisation
            while (avancementValeur.getInfoAvancement().getStatut() == 4);
            
            System.out.println("avancement OK");
            DataHandler dataHandlerRepo   = assitant.resultatCreerProjet(serviceAsynchroneValeur); 
          //  byte[] bytesRep = assitant.resultatCreerProjet(serviceAsynchroneValeur);
            assitant.acquitter(serviceAsynchroneValeur);
        }
        catch (TechDysfonctionnementException e)
        {
        }
        catch (TechIndisponibiliteException e)
        {
        }
        catch (TechProtocolaireException e)
        {
            
        }
    }
}
