package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.delta.stubs.gen.ArticleRequete;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.ArticleAsynchroneReponse;


@XmlType(name = "RlocReponseValeurDeltaOS13EtOS14", propOrder = {
    "reponse"
})
public class RlocReponseValeurDeltaOS13EtOS14 extends ArticleRequete  implements Serializable
{

    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = 2781750692375851957L;
    @XmlElement(name = "return")
    private ReponseDeltaOS13Et14 reponse;

   
    public ReponseDeltaOS13Et14 getReponse()
    {
        return reponse;
    }

    public void setReponse(ReponseDeltaOS13Et14 reponse)
    {
        this.reponse = reponse;
    }

}
