//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.11 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2016.11.16 à 05:32:30 PM CET 
//


package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the fr.gouv.finances.aos.mas.service.stubs.projets.synchrone.dtos package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ProjetReponseDto_QNAME = new QName("", "projetReponseDto");
    private final static QName _ProjetsReponseAsyncDto_QNAME = new QName("", "projetsReponseAsyncDto");
    private final static QName _ProjetsRequeteAsyncDto_QNAME = new QName("", "projetsRequeteAsyncDto");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: fr.gouv.finances.aos.mas.service.stubs.projets.synchrone.dtos
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ProjetReponseDto }
     * 
     */
    public ProjetReponseDto createProjetReponseDto() {
        return new ProjetReponseDto();
    }

    /**
     * Create an instance of {@link ProjetsReponseAsyncDto }
     * 
     */
    public ProjetsReponseAsyncDto createProjetsReponseAsyncDto() {
        return new ProjetsReponseAsyncDto();
    }

    /**
     * Create an instance of {@link ProjetsRequeteAsyncDto }
     * 
     */
    public ProjetsRequeteAsyncDto createProjetsRequeteAsyncDto() {
        return new ProjetsRequeteAsyncDto();
    }

    /**
     * Create an instance of {@link ArticleAsynchroneReponse }
     * 
     */
    public ArticleAsynchroneReponse createArticleAsynchroneReponse() {
        return new ArticleAsynchroneReponse();
    }

    /**
     * Create an instance of {@link ArticleRequete }
     * 
     */
    public ArticleRequete createArticleRequete() {
        return new ArticleRequete();
    }

    /**
     * Create an instance of {@link TechDysfonctionnementErreur }
     * 
     */
    public TechDysfonctionnementErreur createTechDysfonctionnementErreur() {
        return new TechDysfonctionnementErreur();
    }

    /**
     * Create an instance of {@link ErreurImpl }
     * 
     */
    public ErreurImpl createErreurImpl() {
        return new ErreurImpl();
    }

    /**
     * Create an instance of {@link FonctionnelleErreur }
     * 
     */
    public FonctionnelleErreur createFonctionnelleErreur() {
        return new FonctionnelleErreur();
    }

    /**
     * Create an instance of {@link TechProtocolaireErreur }
     * 
     */
    public TechProtocolaireErreur createTechProtocolaireErreur() {
        return new TechProtocolaireErreur();
    }

    /**
     * Create an instance of {@link ProjetRequeteDto }
     * 
     */
    public ProjetRequeteDto createProjetRequeteDto() {
        return new ProjetRequeteDto();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProjetReponseDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "projetReponseDto")
    public JAXBElement<ProjetReponseDto> createProjetReponseDto(ProjetReponseDto value) {
        return new JAXBElement<ProjetReponseDto>(_ProjetReponseDto_QNAME, ProjetReponseDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProjetsReponseAsyncDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "projetsReponseAsyncDto")
    public JAXBElement<ProjetsReponseAsyncDto> createProjetsReponseAsyncDto(ProjetsReponseAsyncDto value) {
        return new JAXBElement<ProjetsReponseAsyncDto>(_ProjetsReponseAsyncDto_QNAME, ProjetsReponseAsyncDto.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProjetsRequeteAsyncDto }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "projetsRequeteAsyncDto")
    public JAXBElement<ProjetsRequeteAsyncDto> createProjetsRequeteAsyncDto(ProjetsRequeteAsyncDto value) {
        return new JAXBElement<ProjetsRequeteAsyncDto>(_ProjetsRequeteAsyncDto_QNAME, ProjetsRequeteAsyncDto.class, null, value);
    }

}
