package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.stream.*;
import javax.xml.transform.stream.StreamSource;

import java.io.InputStream;
import java.util.*;

/**
 * classe générique de dé-sérialisation XML 
 * GenericUnMarshaller.java
 * DOCUMENTEZ_MOI
 * @author mokranii
 * Date: 29 sept. 2016
 */
public class GenericUnMarshaller<A>
{
    private final XMLStreamReader xmlStreamReader; 
    
    private final Class<A> classs; 
    
    private final Unmarshaller deserialiseur; 
    
    private final String nomElementBase ;
    
    private final Map<String, AttributXML> mapAttributs; 
    
    public GenericUnMarshaller(InputStream inputStream, Class<A> classs) 
        throws XMLStreamException, FactoryConfigurationError, JAXBException
    {
        this(inputStream, classs, null); 
    }
    
    public GenericUnMarshaller(InputStream stream, Class<A> classs, String encodage) 
    throws XMLStreamException, FactoryConfigurationError, JAXBException
    {
        this.classs = classs;
        this.deserialiseur = JAXBContext.newInstance(classs).createUnmarshaller();
        if (StringUtile.isNotEmpty(encodage))
        {
            this.xmlStreamReader = XMLInputFactory.newInstance().createXMLStreamReader(stream, encodage);
        }
        else
        {
            this.xmlStreamReader = XMLInputFactory.newInstance().createXMLStreamReader(new StreamSource(stream));
        }
    
        sauterBalisesStartElement_EndElement(XMLStreamConstants.START_DOCUMENT, XMLStreamConstants.DTD, XMLStreamConstants.SPACE);
        nomElementBase = xmlStreamReader.getLocalName();
        mapAttributs = new HashMap<String, AttributXML>();
        for (int i = 0; i < xmlStreamReader.getAttributeCount(); i++)
        {
            mapAttributs.put(xmlStreamReader.getAttributeLocalName(i),
            new AttributXML(xmlStreamReader.getAttributeLocalName(i), xmlStreamReader.getAttributeValue(i)));
        }
        xmlStreamReader.nextTag();
        sauterBalisesStartElement_EndElement(XMLStreamConstants.END_ELEMENT);
    }
    
    
    private void sauterBalisesStartElement_EndElement(int... elements) throws XMLStreamException
    {
        int eventType = xmlStreamReader.getEventType();
        List<Integer> types = new ArrayList<Integer>();
        for (int element : elements)
        {
            types.add(element);
        }
        while (types.contains(eventType))
            eventType = xmlStreamReader.next();
    }
    
    public boolean elementSuivant() throws XMLStreamException
    {
        return xmlStreamReader.hasNext();
    }
    
    public void fermerFulxSXml() throws XMLStreamException
    {
        xmlStreamReader.close();
    }

    public String getNomElementBase()
    {
        return nomElementBase;
    }
    
    public A suivant() throws XMLStreamException, JAXBException
    {
        if (!elementSuivant())
        {   
            throw new NoSuchElementException();
        }
        A value = deserialiseur.unmarshal(xmlStreamReader, classs).getValue();
        sauterBalisesStartElement_EndElement(XMLStreamConstants.CHARACTERS, XMLStreamConstants.END_ELEMENT, XMLStreamConstants.SPACE);
        return value;
    }

    public Map<String, AttributXML> getMapAttributs()
    {
        return mapAttributs;
    }
   
}
