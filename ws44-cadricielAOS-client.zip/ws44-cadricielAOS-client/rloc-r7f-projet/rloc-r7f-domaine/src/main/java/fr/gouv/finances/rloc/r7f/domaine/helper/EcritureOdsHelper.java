package fr.gouv.finances.rloc.r7f.domaine.helper;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//import fr.gouv.finances.rloc.r7f.domaine.ValidationSQLContrat1;
//import fr.gouv.finances.rloc.r7f.domaine.ValidationSQLContrat2;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.MD5Utils;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Resultats;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Constantes;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class EcritureOdsHelper
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(EcritureOdsHelper.class);

    public static void creerFichierReponseODS(List<String> casDeTest) throws RecetteFonctionnelleException
    {

        String repertoire = RecetteUtils.creerRepertoireSortie(Parametres.getRepertoire().getAbsolutePath(),
            Parametres.getFichierODS().getName(), Parametres.getNomOS());

        StringBuilder fichierSortie = new StringBuilder(repertoire).append(File.separator)
            .append(Parametres.getFichierODS().getName().replace(".ods", ""))
            .append(DateHelper.getDateTraitement()).append(".ods");

        File fichierReponse = new File(fichierSortie.toString());

        /*
         * Contient la liste des reponse sur tous les cas de test avec leur arboresance dans le XML
         */
        Resultats resultats = ParserXmlHelper.parsersFichiersReponse(repertoire, casDeTest);
        
        try
        {
            /*
             * Fichier ODS
             */
            SpreadSheet classeur = SpreadSheet.createFromFile(Parametres.getFichierODS());

            ajouterFeuilleOds(classeur, resultats);

            validerReponse(classeur);

            classeur.saveAs(fichierReponse);
        }
        catch (IOException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
    }

    private static void validerReponse(SpreadSheet classeur) throws RecetteFonctionnelleException
    {
        Map<String, String> md5ValideAttendu = MD5Utils.calculerMD5FeuilleOds(classeur, Constantes.ONGLET_REPONSE_ATTENDU);

        Map<String, String> md5Valide = MD5Utils.calculerMD5FeuilleOds(classeur, Constantes.ONGLET_REPONSE);

        // comparaision des MD5
        int nbOK = 0;
        int nbKO = 0;
        int nbAucuneComparaison = 0;

        LOGGER.info("*********************************************");
        LOGGER.info(Parametres.getFichierODS().getName());

        for (String nomDuTest : md5Valide.keySet())
        {
            String md5 = md5Valide.get(nomDuTest);
            String md5Attendu = md5ValideAttendu.get(nomDuTest);

            String resultat = "";
            /*
             * Validation SQL
             */
            if (md5.contains("idlocal"))
            {
                boolean isValide = false;

                if (Parametres.getNomOS().equals("OS10"))
                {
                   // isValide = ValidationSQLContrat1.validationSqlOS10(nomDuTest, md5.replaceAll("idlocal", ""));
                }
                else if (Parametres.getNomOS().equals("OS01"))
                {
                    if (Parametres.getContrat().getNomContrat().equals("contrat_rlocmas_creation_provisoire_1"))
                    {
                     //   isValide = ValidationSQLContrat1.validationSqlOS01(nomDuTest, md5.replaceAll("idlocal", ""));
                    }
                    else
                    {
                    //    isValide = ValidationSQLContrat2.validationSqlOS01(nomDuTest, md5.replaceAll("idlocal", ""));
                    }
                }
                else if (Parametres.getNomOS().equals("OS03"))
                {
                  //  isValide = ValidationSQLContrat1.validationSqlOS03(nomDuTest);
                }
                else if (Parametres.getNomOS().equals("OS02"))
                {
                   // isValide = ValidationSQLContrat1.validationSqlOS02(nomDuTest);
                }
                else if (Parametres.getNomOS().equals("OS04"))
                {
                    //isValide = ValidationSQLContrat1.validationSqlOS04(nomDuTest);
                }
                else if (Parametres.getNomOS().equals("OS05"))
                {
                  //  isValide = ValidationSQLContrat1.validationSqlOS05(nomDuTest);
                }
                else
                {
                    resultat = "Aucune comparaison SQL disponible";
                }

                if (isValide)
                {
                    resultat = "OK";
                    nbOK++;
                }
                else
                {
                    resultat = "KO";
                    nbKO++;
                }
            }
            else if (md5Attendu == null)
            {
                resultat = "aucune comparaison";
                nbAucuneComparaison++;
            }
            else if (md5Attendu.equals(md5))
            {
                resultat = "OK";
                nbOK++;
            }
            else
            {
                resultat = "KO";
                nbKO++;
            }

            LOGGER.info(new StringBuilder(nomDuTest).append(" : ").append(resultat).toString());
        }

        LOGGER.info(new StringBuilder("Total OK /total cas = ").append(nbOK).toString());
        LOGGER.info(new StringBuilder("Total KO /total cas = ").append(nbKO).toString());
        LOGGER.info(new StringBuilder("Total aucune comparaison /total cas = ").append(nbAucuneComparaison).toString());
        LOGGER.info("*********************************************");
    }

    private static void ajouterFeuilleOds(SpreadSheet classeur, Resultats resultats)
    {
        Sheet shReponse = classeur.addSheet(Constantes.ONGLET_REPONSE);

        // nb ligne MAX
        int nbLigne = resultats.getArborescences().size() + 1;
        shReponse.setRowCount(nbLigne);

        // nb colonne max
        int nbColonne = resultats.getListe().size() + 2;
        shReponse.setColumnCount(nbColonne);

        // titre colonne
        shReponse.setValueAt("arborescences", 0, 0);
        shReponse.setValueAt("attributs", 1, 0);

        int numeroLigne = 1;
        for (String arborescence : resultats.getArborescences())
        {
            shReponse.setValueAt(RecetteUtils.recupererArborescence(arborescence), 0, numeroLigne);
            shReponse.setValueAt(RecetteUtils.recupererAttribut(arborescence), 1, numeroLigne++);
        }

        int numeroColonne = 2;

        for (int i = 0; i < resultats.getListe().size(); i++)
        {
            Map<String, String> casDeTest = resultats.getListe().get(i);

            numeroLigne = 1;
            boolean topContenu = false;

            for (String arborescence : resultats.getArborescences())
            {
                if (casDeTest.get(arborescence) != null)
                {
                    shReponse.setValueAt(casDeTest.get(arborescence), numeroColonne, numeroLigne);
                    topContenu = true;
                }
                numeroLigne++;
            }

            if (topContenu)
            {
                shReponse.setValueAt(casDeTest.get("nomDuTest"), numeroColonne++, 0);
            }
        }
    }
}
