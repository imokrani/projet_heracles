package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;


public class ReponseDeltaOS13Et14 extends Reponse
{
    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = -4665244247817712050L;
    
    private List<String> idsLocal;

    @XmlElement(name = "idLocal")
    public List<String> getIdsLocal()
    {
        return idsLocal;
    }

    public void setIdsLocal(List<String> idsLocal)
    {
        this.idsLocal = idsLocal;
    }
    
}
