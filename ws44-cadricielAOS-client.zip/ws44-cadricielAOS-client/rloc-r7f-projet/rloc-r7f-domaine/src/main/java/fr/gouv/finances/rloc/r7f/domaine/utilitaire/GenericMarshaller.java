package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

import java.io.IOException;
import java.io.OutputStream;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

/**
 * classe générique de sérialisation XML  
 * GenericMarshaller.java
 * DOCUMENTEZ_MOI
 * @author mokranii
 * Date: 29 sept. 2016
 */
public class GenericMarshaller<T>
{
    private static final String ENCONDIG = "UTF-8";
    private static final String ENCODING_VERSION  = "1.0"; 
    private XMLStreamWriter xmlWriter; 
    private final Marshaller marshaller; 
    
    private Class<T> typeClasse;

    public GenericMarshaller(Class<T> typeClasse) throws JAXBException
    {
        super();
        this.typeClasse = typeClasse;
        JAXBContext context = JAXBContext.newInstance(typeClasse); 
        marshaller = context.createMarshaller(); 
        marshaller.setProperty(Marshaller.JAXB_ENCODING, ENCONDIG);
        marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
        marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
    } 
    
     /** Initailiser le ficheir XML **/
     public void initialisationFluxEXml(OutputStream outputStream, String encoding, String elementXmlBase, AttributXML... attsXml)
     throws XMLStreamException, IOException
     {
         xmlWriter = XMLOutputFactory.newInstance().createXMLStreamWriter(outputStream, encoding); 
         xmlWriter.writeStartDocument(encoding, ENCODING_VERSION);
         xmlWriter.writeStartElement(elementXmlBase);
         //ecrire également les autres éléments
         for(AttributXML attribut : attsXml)
         {
             xmlWriter.writeAttribute(attribut.getNom(), attribut.getValeur());
         }
     }

     /** Continuer à écrire dans le fichier XML**/
     public void initialisationFluxEXmlSansAttributs(OutputStream outputStream, String encoding)
     throws XMLStreamException, IOException
     {
         xmlWriter = XMLOutputFactory.newInstance().createXMLStreamWriter(outputStream, encoding); 
         xmlWriter.writeStartDocument(encoding, ENCODING_VERSION);
     }
     
     public void ecrireElement(T t)
     throws XMLStreamException, JAXBException
     {
         ecrireElementBalise(t, null);
     }
     
     public void ecrireElementBalise(T t, String baliseXml)
     throws XMLStreamException, JAXBException
     {
         if(StringUtile.isNotEmpty(baliseXml))
         {
             JAXBElement<T> element = new JAXBElement<T>(QName.valueOf(baliseXml), typeClasse, t); 
             marshaller.marshal(element, xmlWriter);
             xmlWriter.flush();
         }
         else
         {
             JAXBElement<T> element = new JAXBElement<T>(QName.valueOf(typeClasse.getSimpleName()), typeClasse, t); 
             marshaller.marshal(element, xmlWriter);
             xmlWriter.flush();
         }
     }
     
     /** Fermer le flux XML ouvert en écriture **/
     public void fermerFluxEXml(boolean flag)
     throws XMLStreamException
     {
         xmlWriter.writeEndDocument();
         if(flag)
         {
              xmlWriter.close();             
         }
     }
}
