package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import java.io.Serializable;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;

import fr.gouv.impots.appli.commun.frameworks.gestionerreurs.erreurs.FonctionnelleErreur;

public class Reponse implements Serializable
{  
    
    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = -6257945552182473746L;
    
    /** The liste erreurs fonctionnelles. */
    private List<FonctionnelleErreur> listeErreursFonctionnelles;
    public Reponse()
    {
        
    }
    
    @XmlElementWrapper(name = "listeErreursFonctionnnelles", required=false)
    @XmlElement(name = "erreur",nillable=true)
    public List<FonctionnelleErreur> getListeErreursFonctionnelles()
    {
        return listeErreursFonctionnelles;
    }

    public void setListeErreursFonctionnelles(List<FonctionnelleErreur> listeErreursFonctionnelles)
    {
        this.listeErreursFonctionnelles = listeErreursFonctionnelles;
    }
    
}
