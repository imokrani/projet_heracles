package fr.gouv.finances.rloc.r7f.domaine.helper;

import java.io.File;
import java.io.IOException;

import org.apache.commons.lang3.StringUtils;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;

import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Constantes;

public class LectureOdsHelper
{

    private  SpreadSheet spreadSheet = null;
    
    private  File fichierODS = null;

    private  Sheet sheet = null;

    private  int ligne = 0;

    private  int colonne = 0;

    public LectureOdsHelper (File fichierODS) throws RecetteFonctionnelleException
    {
        this.fichierODS = fichierODS;
        initSheet();
    }
    
    private  void initSheet() throws RecetteFonctionnelleException
    {
        sheet = null;

        try
        {
            spreadSheet = SpreadSheet.createFromFile(fichierODS); 
            
            sheet = spreadSheet.getSheet(Constantes.ONGLET_ENTREE);
            
            if (sheet  == null)
            {
                throw new RecetteFonctionnelleException(new StringBuilder(fichierODS.getName())
                        .append(": La feuille ").append(Constantes.ONGLET_ENTREE)
                        .append(" n'existe pas").toString());   
            }
            
        }
        catch (IOException e)
        {
            StringBuilder message = new StringBuilder("Erreur de lecture :").append(fichierODS);
            throw new RecetteFonctionnelleException(message.toString(), e);
        }
    }
    
    public  String getNextValueSheet() throws RecetteFonctionnelleException
    {
        
        String valeur = sheet.getCellAt(colonne, ligne++).getTextValue().trim();

        if (StringUtils.isBlank(valeur))
        {
            valeur = "";
        }

        return valeur;
    }
    
    /**
     * saut de ligne dans le fichier ods
     */
    public  void sautDeligne()
    {
        ligne++;
    }
  
    public void setFichierODS(File fichierODS)
    {
        this.fichierODS = fichierODS;
    }

    public  Sheet getSheet() throws RecetteFonctionnelleException
    {       
        return sheet;
    }

    public  int getLigne()
    {
        return ligne;
    }

    public  void setLigne(int ligne)
    {
        this.ligne = ligne;
    }

    public  int getColonne()
    {
        return colonne;
    }

    public void setColonne(int colonne)
    {
        this.colonne = colonne;
    }
    
    

}
