//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.11 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2016.11.16 à 05:32:30 PM CET 
//


package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour articleSynchroneReponse complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="articleSynchroneReponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{}articleRequete"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fonctionnelleErreur" type="{}fonctionnelleErreur" minOccurs="0"/&gt;
 *         &lt;element name="techProtocolaireErreur" type="{}techProtocolaireErreur" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "articleSynchroneReponse", propOrder = {
    "fonctionnelleErreur",
    "techProtocolaireErreur"
})
@XmlSeeAlso({
    ArticleAsynchroneReponse.class
})
public abstract class ArticleSynchroneReponse
    extends ArticleRequete
{

    protected FonctionnelleErreur fonctionnelleErreur;
    protected TechProtocolaireErreur techProtocolaireErreur;

    /**
     * Obtient la valeur de la propriété fonctionnelleErreur.
     * 
     * @return
     *     possible object is
     *     {@link FonctionnelleErreur }
     *     
     */
    public FonctionnelleErreur getFonctionnelleErreur() {
        return fonctionnelleErreur;
    }

    /**
     * Définit la valeur de la propriété fonctionnelleErreur.
     * 
     * @param value
     *     allowed object is
     *     {@link FonctionnelleErreur }
     *     
     */
    public void setFonctionnelleErreur(FonctionnelleErreur value) {
        this.fonctionnelleErreur = value;
    }

    /**
     * Obtient la valeur de la propriété techProtocolaireErreur.
     * 
     * @return
     *     possible object is
     *     {@link TechProtocolaireErreur }
     *     
     */
    public TechProtocolaireErreur getTechProtocolaireErreur() {
        return techProtocolaireErreur;
    }

    /**
     * Définit la valeur de la propriété techProtocolaireErreur.
     * 
     * @param value
     *     allowed object is
     *     {@link TechProtocolaireErreur }
     *     
     */
    public void setTechProtocolaireErreur(TechProtocolaireErreur value) {
        this.techProtocolaireErreur = value;
    }

}
