package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class MD5Utils
{

    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(MD5Utils.class);

    public static Map<String, String> calculerMD5FeuilleOds(SpreadSheet classeur, String nomFeuille) throws RecetteFonctionnelleException
    {
        Map<String, String> resultat = new HashMap<String, String>();
        Sheet sheet = classeur.getSheet(nomFeuille);

        String osExclu = "OS10 OS01 0S02 0S03 OS05 OS04";

        if (sheet != null)
        {
            int nbColonne = sheet.getColumnCount();
            int nbLigne = sheet.getRowCount();

            colonne: for (int colonne = 2; colonne < nbColonne; colonne++)
            {
                String nomDuTest = sheet.getCellAt(colonne, 0).getTextValue().trim();

                if (nomDuTest.equals(""))
                {
                    break;
                }

                StringBuilder valeurs = new StringBuilder();

                for (int ligne = 1; ligne < nbLigne; ligne++)
                {
                    String attribut = sheet.getCellAt(1, ligne).getTextValue().trim();
                    String valeur = sheet.getCellAt(colonne, ligne).getTextValue().trim();

                    if (!StringUtils.isBlank(valeur))
                    {
                        // Certaines OS sont à exclure du calcul MD5
                        if (osExclu.contains(Parametres.getNomOS()) && 
                            (attribut.equals("idlocal") || attribut.equals("codeRetour")))
                        {
                            resultat.put(nomDuTest, new StringBuilder("idlocal").append(valeur).toString());
                            continue colonne;
                        }

                        valeurs.append(attribut).append(valeur);
                    }

                }
                resultat.put(nomDuTest, caluclerMd5(valeurs.toString()));
            }
        }
        else
        {
            LOGGER.warn(new StringBuilder(Parametres.getFichierODS().getName()).append(": La feuille ")
                .append(nomFeuille).append(" n'existe pas").toString());
        }

        return resultat;
    }

    private static String caluclerMd5(String chaine) throws RecetteFonctionnelleException
    {
        StringBuilder md5 = new StringBuilder();

        MessageDigest messageDigest;
        try
        {
            messageDigest = MessageDigest.getInstance("MD5");
            messageDigest.update(chaine.toString().getBytes());

            byte byteData[] = messageDigest.digest();
            // convert the byte to hex format method 1

            for (int i = 0; i < byteData.length; i++)
            {
                md5.append(Integer.toString((byteData[i] & 0xff) + 0x100, 16).substring(1));
            }
        }
        catch (NoSuchAlgorithmException e)
        {
            throw new RecetteFonctionnelleException(e);
        }

        return md5.toString();
    }

}
