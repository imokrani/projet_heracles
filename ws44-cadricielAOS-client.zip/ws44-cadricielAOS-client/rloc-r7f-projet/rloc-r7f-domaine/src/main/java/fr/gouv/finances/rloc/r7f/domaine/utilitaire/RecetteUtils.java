package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.Binding;
import javax.xml.ws.BindingProvider;

import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.domaine.helper.DateHelper;
import fr.gouv.finances.rloc.r7f.transverse.ContratApplicatif;
import fr.gouv.finances.rloc.r7f.transverse.HTTPNomClientHandler;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Constantes;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class RecetteUtils
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(RecetteUtils.class);
    
    public static int getTailleMax(int... tailles)
    {
        List<Integer> list = new ArrayList<Integer>();

        for (int i = 0; i < tailles.length; i++)
        {
            list.add(tailles[i]);
        }

        Collections.sort(list);

        return list.get(list.size() - 1);
    }

    public static List<String> convertirEnliste(String chaine)
    {
        List<String> liste = new ArrayList<String>();

        if (chaine != null)
        {
            liste = Arrays.asList(chaine.split(";"));
        }
        return liste;

    }

    public static XMLGregorianCalendar stringToXMLGregorianCalendar(String string) throws RecetteFonctionnelleException
    {
        XMLGregorianCalendar result = null;

        if (string != null && !string.equals(""))
        {
            Date date;
            SimpleDateFormat simpleDateFormat;
            GregorianCalendar gregorianCalendar;

            if (string.contains("T"))
            {
                simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
                simpleDateFormat.setLenient(false);
            }
            else
            {
                simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
                simpleDateFormat.setLenient(false);
            }

            try
            {
                date = simpleDateFormat.parse(string);
            }
            catch (ParseException e)
            {
//                simpleDateFormat = new SimpleDateFormat("dd-MM-yyyy");
//                try
//                {
//                    date = simpleDateFormat.parse(string);
//                }
//                catch(ParseException eX)
//                {
                    StringBuilder message = new StringBuilder("Le format date incorrect :").append(string);
                    throw new RecetteFonctionnelleException(message.toString(), e);
                //}
            }
            gregorianCalendar = (GregorianCalendar) GregorianCalendar.getInstance();
            gregorianCalendar.setTime(date);

            try
            {
                result = DatatypeFactory.newInstance().newXMLGregorianCalendar(gregorianCalendar);
            }
            catch (DatatypeConfigurationException e)
            {
                StringBuilder message = new StringBuilder("Le format date incorrect :").append(string);
                throw new RecetteFonctionnelleException(message.toString(), e);
            }
        }
        return result;
    }

    public static String recupererAttribut(String arborescence)
    {
        File file = new File(arborescence);
        File parent = new File(file.getParent());

        String nom = parent.getName();
        
        //suppression du numéro en fin de ligne "_*"
        return nom.substring(0, nom.lastIndexOf("_"));
    }

    public static String recupererArborescence(String arborescence)
    {
        File file = new File(arborescence);
        File parent = new File(file.getParent());

        String chemin = parent.getAbsolutePath();
        
        //suppression du numéro en fin de ligne "_*"
        return chemin.substring(0, chemin.lastIndexOf("_"));
    }

    public static String creerArborescenceFichierReponse(String repertoireSortie, String fichierODS, String nomOS, String nomDuTest)
    {
        // Suppression des espaces
        nomDuTest = nomDuTest.replaceAll(" ", "_");

        // Chemin complet du fichier xml de sortie
        StringBuilder nomDuFichier = new StringBuilder(creerRepertoireSortie(repertoireSortie, fichierODS, nomOS))
            .append(File.separator)
            .append(fichierODS.replace(".ods", "")).append("_")
            .append(nomDuTest)
            .append(DateHelper.getDateTraitement()).append(".xml");

        return nomDuFichier.toString();
    }
    
    

    public static String creerRepertoireSortie(String repertoireSortie, String fichierODS, String nomOS)
    {
        StringBuilder chemin = new StringBuilder(repertoireSortie)
            .append(File.separator)
            .append(nomOS).append(File.separator)
            .append(fichierODS.replace(".ods", ""));

        File repertoire = new File(chemin.toString());

        if (!repertoire.isDirectory())
        {
            repertoire.mkdirs();
        }

        return chemin.toString();
    }

    public static ContratApplicatif recupererContratApplicatif() throws RecetteFonctionnelleException
    {
        ContratApplicatif contrat = new ContratApplicatif();

        SpreadSheet spreadSheet = null;
        try
        {
            spreadSheet = SpreadSheet.createFromFile(Parametres.getFichierODS());
        }
        catch (IOException e)
        {
            throw new RecetteFonctionnelleException(e);
        } 
        
        Sheet sheet = spreadSheet.getSheet(Constantes.ONGLET_CONTRAT);

        if (sheet == null)
        {
            String message = new StringBuilder("L'onget ").append(Constantes.ONGLET_CONTRAT)
                .append(" n'existe pas").toString();
            throw new RecetteFonctionnelleException(message);
        }

        contrat.setApplication(sheet.getCellAt(1, 0).getTextValue().trim());
        contrat.setNomContrat(sheet.getCellAt(1, 1).getTextValue().trim());

        return contrat;
    }
       
    public static void afficherRequete(StringBuilder query, List<String> parametres)
    {        
        // découper le requete            
        List<String> requeteDecoupee = Arrays.asList(query.toString().split("\\?"));

        StringBuilder requeteAfficher = new StringBuilder();
        
        for (int i = 0; i < requeteDecoupee.size(); i++)
        {
                if(requeteDecoupee.get(i).equals(" "))
                {
                    break;
                }
            
                requeteAfficher.append(requeteDecoupee.get(i)).append("'").append(parametres.get(i)).append("'");
        } 
        
        LOGGER.debug(new StringBuilder("query= ").append(requeteAfficher).toString());       
    }
    
    public static <T> void ajouterEnteteHTTP(T port)
    {
        // HandlerChain installieren
        Binding binding = ((BindingProvider) port).getBinding();
        List hchain = binding.getHandlerChain();
        if (hchain == null) 
        {
          hchain = new ArrayList();
        }
        hchain.add(new HTTPNomClientHandler());
        binding.setHandlerChain(hchain);
    }
    
}
