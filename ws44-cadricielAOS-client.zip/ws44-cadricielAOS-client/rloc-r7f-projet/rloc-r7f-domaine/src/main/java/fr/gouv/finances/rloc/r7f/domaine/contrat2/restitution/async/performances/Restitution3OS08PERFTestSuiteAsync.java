package fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution.async.performances;



import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.transverse.TIRS;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class Restitution3OS08PERFTestSuiteAsync extends TestSuite
{


    public Restitution3OS08PERFTestSuiteAsync()
    {
        super();
    }

    public void lancer() throws RecetteFonctionnelleException
    {
        System.out.println("TEST OK");
        /** Recupérer toute les information qui concerne le TIR **/
        TIRS tir = recupererParametresTirs(); 
        System.out.println(tir.getDepartement());
        System.out.println(tir.getNombreBloc());
        System.out.println(tir.getTailleBloc());
        System.out.println(tir.getTypeTir());
    }
    
    
    private TIRS recupererParametresTirs() throws RecetteFonctionnelleException
    {
         initSheet();
         ligne = 1;
         colonne = 1;
         TIRS tir = new TIRS(); 
         tir.setDepartement(getNextValueSheet());
         tir.setNombreBloc(getNextValueSheet());
         tir.setTailleBloc(Integer.parseInt(getNextValueSheet()));
         tir.setTypeTir(getNextValueSheet());    
         return tir; 
    }
}