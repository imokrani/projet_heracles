package fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.gouv.finances.rloc.r7f.contrat2.restitution.RestitutionLocalSynchroneInterface;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.RlocListeReponseValeurOS8;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.RlocRequeteLocalOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.RlocRequeteParametresOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.RlocRequeteValeurOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.SousRequeteValeurOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.TechDysfonctionnementErreur_Exception;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.TechIndisponibiliteErreur_Exception;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.TechProtocolaireErreur_Exception;
import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.helper.EcritureOdsHelper;
import fr.gouv.finances.rloc.r7f.domaine.helper.EcritureXmlHelper;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.ConstantesWSDL;

public class Restitution2OS08TestSuite extends TestSuite
{
    private RestitutionLocalSynchroneInterface restitution;

    public Restitution2OS08TestSuite()
    {
        super();
    }

    public void lancer() throws RecetteFonctionnelleException
    {
        // Construction de la requête
        Map<String, RlocRequeteValeurOS08> map = mappingFichierODS();

        restitution = creerService("RestitutionLocalSynchroneInterface", ConstantesWSDL.RESTITUTION)
                .getPort(RestitutionLocalSynchroneInterface.class);
        
        RecetteUtils.ajouterEnteteHTTP(restitution);
        
        for (String nomDuTest : casDeTest)
        {   
            // Appel du service
            RlocListeReponseValeurOS8 reponse = executerRequete(map.get(nomDuTest));

            // Constrution de la réponse
            EcritureXmlHelper.creerFichierReponseXml(reponse, nomDuTest, RlocListeReponseValeurOS8.class, ConstantesWSDL.RESTITUTION); 
        }
        
        EcritureOdsHelper.creerFichierReponseODS(casDeTest);
    }

    public Map<String, RlocRequeteValeurOS08> mappingFichierODS() throws RecetteFonctionnelleException
    {
        Map<String, RlocRequeteValeurOS08> map = new HashMap<String, RlocRequeteValeurOS08>();

        initSheet();

        int nbColonne = sheet.getColumnCount();

        // mapping fichier ods
        for (int i = 2; i <= nbColonne; i++)
        {
            ligne = 0;
            colonne = i;

            RlocRequeteValeurOS08 requete = new RlocRequeteValeurOS08();
            List<SousRequeteValeurOS08> listeSousRequete = requete.getRequete();

            String nomDuTest = getNextValueSheet();

            if (nomDuTest.equals(""))
            {
                break;
            }

            RlocRequeteLocalOS08 local = new RlocRequeteLocalOS08();
            local.setIdLocal(getNextValueSheet());
            RlocRequeteParametresOS08 lecture = new RlocRequeteParametresOS08();
  
            lecture.setDtValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setDtDebutValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setDtFinValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setLbValidite(getNextValueSheet());
            lecture.setLbHistorisation(getNextValueSheet());

            SousRequeteValeurOS08 sousRequete = new SousRequeteValeurOS08();
            sousRequete.setLocal(local);
            sousRequete.setLecture(lecture);

            listeSousRequete.add(sousRequete);
            map.put(nomDuTest, requete);            
            casDeTest.add(nomDuTest);
        }

        return map;
    }

    public RlocListeReponseValeurOS8 executerRequete(RlocRequeteValeurOS08 serviceRequeteValeur2) throws RecetteFonctionnelleException
    {
        RlocListeReponseValeurOS8 reponse = null;

        try
        {
            reponse = restitution.restituerLocalEtVlGlobaliseeParIdLocal(serviceRequeteValeur2);
        }
        catch (TechDysfonctionnementErreur_Exception e)
        {
            String message = "Erreur lors de l'execution du service";
            throw new RecetteFonctionnelleException(message, e);
        }
        catch (TechProtocolaireErreur_Exception e)
        {
            String message = "Erreur protocolaire lors de l'execution du service";
            throw new RecetteFonctionnelleException(message, e);
        }
        catch (TechIndisponibiliteErreur_Exception e)
        {
            String message = "Le service est indisponible";
            throw new RecetteFonctionnelleException(message, e);
        }

        return reponse;
    }
}
