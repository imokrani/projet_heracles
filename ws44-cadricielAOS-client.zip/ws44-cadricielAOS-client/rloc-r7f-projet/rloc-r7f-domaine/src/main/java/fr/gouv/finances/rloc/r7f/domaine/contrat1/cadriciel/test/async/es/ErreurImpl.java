//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.11 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2016.11.16 à 05:32:30 PM CET 
//


package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Classe Java pour erreurImpl complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="erreurImpl"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="id" type="{http://www.w3.org/2001/XMLSchema}base64Binary" minOccurs="0"/&gt;
 *         &lt;element name="code" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="codeAsString" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="libelle" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="descriptif" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="severite" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="dateHeure" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "erreurImpl", propOrder = {
    "id",
    "code",
    "codeAsString",
    "libelle",
    "descriptif",
    "severite",
    "dateHeure"
})
@XmlSeeAlso({
    TechDysfonctionnementErreur.class,
    FonctionnelleErreur.class,
    TechProtocolaireErreur.class
})
public class ErreurImpl {

    protected byte[] id;
    protected int code;
    protected String codeAsString;
    protected String libelle;
    protected String descriptif;
    protected int severite;
    @XmlSchemaType(name = "dateTime")
    protected XMLGregorianCalendar dateHeure;

    /**
     * Obtient la valeur de la propriété id.
     * 
     * @return
     *     possible object is
     *     byte[]
     */
    public byte[] getId() {
        return id;
    }

    /**
     * Définit la valeur de la propriété id.
     * 
     * @param value
     *     allowed object is
     *     byte[]
     */
    public void setId(byte[] value) {
        this.id = value;
    }

    /**
     * Obtient la valeur de la propriété code.
     * 
     */
    public int getCode() {
        return code;
    }

    /**
     * Définit la valeur de la propriété code.
     * 
     */
    public void setCode(int value) {
        this.code = value;
    }

    /**
     * Obtient la valeur de la propriété codeAsString.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCodeAsString() {
        return codeAsString;
    }

    /**
     * Définit la valeur de la propriété codeAsString.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCodeAsString(String value) {
        this.codeAsString = value;
    }

    /**
     * Obtient la valeur de la propriété libelle.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLibelle() {
        return libelle;
    }

    /**
     * Définit la valeur de la propriété libelle.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLibelle(String value) {
        this.libelle = value;
    }

    /**
     * Obtient la valeur de la propriété descriptif.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescriptif() {
        return descriptif;
    }

    /**
     * Définit la valeur de la propriété descriptif.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescriptif(String value) {
        this.descriptif = value;
    }

    /**
     * Obtient la valeur de la propriété severite.
     * 
     */
    public int getSeverite() {
        return severite;
    }

    /**
     * Définit la valeur de la propriété severite.
     * 
     */
    public void setSeverite(int value) {
        this.severite = value;
    }

    /**
     * Obtient la valeur de la propriété dateHeure.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public XMLGregorianCalendar getDateHeure() {
        return dateHeure;
    }

    /**
     * Définit la valeur de la propriété dateHeure.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDateHeure(XMLGregorianCalendar value) {
        this.dateHeure = value;
    }

}
