package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

public class ImgLocalOS13Et14 implements java.io.Serializable
{
    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = -1151004089115456144L;
    
    private String typeDesc;
    
    public ImgLocalOS13Et14()
    {
        
    }

    public String getTypeDesc()
    {
        return typeDesc;
    }

    public void setTypeDesc(String typeDesc)
    {
        this.typeDesc = typeDesc;
    }

    @Override
    public String toString()
    {
        return " [typeDesc=" + typeDesc + "]";
    }
}
