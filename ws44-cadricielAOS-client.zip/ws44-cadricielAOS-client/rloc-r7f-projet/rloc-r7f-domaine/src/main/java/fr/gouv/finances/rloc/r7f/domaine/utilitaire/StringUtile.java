package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

import org.apache.commons.lang3.StringUtils;

/**
 * Traitement des chaine de caractères 
 * StringUtile.java
 * DOCUMENTEZ_MOI
 * @author mokranii
 * Date: 29 sept. 2016
 */
public class StringUtile extends StringUtils
{

}
