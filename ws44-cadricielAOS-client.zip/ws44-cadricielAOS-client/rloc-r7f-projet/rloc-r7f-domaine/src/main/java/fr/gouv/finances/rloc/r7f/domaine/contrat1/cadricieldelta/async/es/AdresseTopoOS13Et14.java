package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "", propOrder = {"cdDept","cdCommune","cdVoie"})
public class AdresseTopoOS13Et14 implements java.io.Serializable
{
    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = 601220569711502236L;
    private String cdDept = ""; 
    private String cdCommune = "";    
    private String cdVoie = "";
    
    public AdresseTopoOS13Et14()
    {
    }

    @XmlElement(required = true)
    public String getCdDept()
    {
        return cdDept;
    }

    public void setCdDept(String cdDept)
    {
        this.cdDept = cdDept;
    }

    public String getCdCommune()
    {
        return cdCommune;
    }

    public void setCdCommune(String cdCommune)
    {
        this.cdCommune = cdCommune;
    }

    public String getCdVoie()
    {
        return cdVoie;
    }

    public void setCdVoie(String cdVoie)
    {
        this.cdVoie = cdVoie;
    }

    @Override
    public String toString()
    {
        return "[cdDept=" + cdDept + ", cdCommune=" + cdCommune + ", cdVoie=" + cdVoie + "]";
    }
}
