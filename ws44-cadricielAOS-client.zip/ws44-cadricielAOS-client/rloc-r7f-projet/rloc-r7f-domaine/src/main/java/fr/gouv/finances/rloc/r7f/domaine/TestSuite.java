package fr.gouv.finances.rloc.r7f.domaine;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebServiceException;

import org.apache.commons.lang3.StringUtils;
import org.jopendocument.dom.spreadsheet.Sheet;
import org.jopendocument.dom.spreadsheet.SpreadSheet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Constantes;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public abstract class TestSuite
{
    /** Logger */
    private static final Logger LOGGER = LoggerFactory.getLogger(TestSuite.class);

    protected SpreadSheet spreadSheet = null;

    protected Sheet sheet = null;

    protected int ligne = 0;

    protected int colonne = 0;
    
    protected boolean isErreur = false;
    
    private static final String CONTEXTE_SYNC = "RLOC-services"; 
    private static final String CONTEXTE_ASYNC = "RLOC-services-async"; 
    
    protected List<String> casDeTest = new ArrayList<String>();
   
    public TestSuite()
    {

    }

    public abstract void lancer() throws RecetteFonctionnelleException;

    public final void initSheet() throws RecetteFonctionnelleException
    {
        sheet = null;

        try
        {
            spreadSheet = SpreadSheet.createFromFile(Parametres.getFichierODS()); 
            
            sheet = spreadSheet.getSheet(Constantes.ONGLET_ENTREE);
            
            if (sheet  == null)
            {
                throw new RecetteFonctionnelleException(new StringBuilder(Parametres.getFichierODS().getName())
                        .append(": La feuille ").append(Constantes.ONGLET_ENTREE)
                        .append(" n'existe pas").toString());   
            }
            
        }
        catch (IOException e)
        {
            StringBuilder message = new StringBuilder("Erreur de lecture du fichier :").append(Parametres.getFichierODS());
            throw new RecetteFonctionnelleException(message.toString(), e);
        }
    }

    public Service creerService(String nomDuService, String wsdl) throws RecetteFonctionnelleException
    {
        URL url = null;
        Service service = null;
        String port=caculerPortService(Parametres.getContrat().getApplication(), Parametres.getHost()); 

        StringBuilder urlString = null;
        StringBuilder urlWsdl = null;
        StringBuilder targetNameSpace = null;
        try
        {            
           
            urlWsdl = new StringBuilder("/services/").append(Parametres.getContrat().getNomContrat())
                                .append("/").append(wsdl);
       
            urlString = new StringBuilder("http://").append(Parametres.getHost())
                                .append(":").append(port).append("/").append(Parametres.getContrat().getApplication())
                                .append(urlWsdl);
            
            LOGGER.info(new StringBuilder("url: ").append(urlString).toString());

            url = new URL(urlString.toString());

            targetNameSpace = new StringBuilder(Constantes.PREFIX_TARGET_NAME_SPACE)
                                .append(urlWsdl.toString().replace("?wsdl", ""));

            QName qname = new QName(targetNameSpace.toString(), nomDuService);

            service = Service.create(url, qname); 
      
        }
        catch (MalformedURLException e)
        {
            StringBuilder message = new StringBuilder("URL incorrecte : ").append(urlString);
            throw new RecetteFonctionnelleException(message.toString(), e);
        }
        catch (WebServiceException e)
        {
            throw new RecetteFonctionnelleException(e);
        }

        return service;
    }

    public String getNextValueSheet()
    {
        String valeur = sheet.getCellAt(colonne, ligne++).getTextValue().trim();

        if (StringUtils.isBlank(valeur))
        {
            valeur = "";
        }

        return valeur;
    }
    
    /**
     * saut de ligne dans le fichier ods
     */
    public void sautDeligne()
    {
        ligne++;
    }
    
    /**
     * 
     * Cette methode calcul le port du service à partir du nom de l'application souhaitée
     *
     * @param nomApplication
     * @return
     */
    private String caculerPortService(String nomApplication, String hostOs)
    {
        String port = "8180";
        
        if(hostOs.equals("127.0.0.1"))
        {
             port = "8080";
             if(nomApplication.contains("-sync"))
             {
                 Parametres.getContrat().setApplication(CONTEXTE_SYNC);
             }
             if(nomApplication.contains("-async"))
             {
                 Parametres.getContrat().setApplication(CONTEXTE_ASYNC);
             } 
        }
        else
        {
            if(nomApplication.contains("-sync"))
            {
                return "8180"; 
            }
            if(nomApplication.contains("-async"))
            {
                return "8380"; 
            }    
        }
        return port;     
    }

}
