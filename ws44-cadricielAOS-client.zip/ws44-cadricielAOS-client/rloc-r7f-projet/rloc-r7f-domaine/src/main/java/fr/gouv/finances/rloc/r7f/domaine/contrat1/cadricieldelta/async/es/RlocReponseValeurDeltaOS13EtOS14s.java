package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "RlocReponseValeurDeltaOS13EtOS14s", propOrder = {
    "RlocReponseValeurDeltaOS13EtOS14"
})
public class RlocReponseValeurDeltaOS13EtOS14s
{

    private RlocReponseValeurDeltaOS13EtOS14 RlocReponseValeurDeltaOS13EtOS14;

    public RlocReponseValeurDeltaOS13EtOS14 getRlocReponseValeurDeltaOS13EtOS14()
    {
        return RlocReponseValeurDeltaOS13EtOS14;
    }

    public void setRlocReponseValeurDeltaOS13EtOS14(RlocReponseValeurDeltaOS13EtOS14 rlocReponseValeurDeltaOS13EtOS14)
    {
        RlocReponseValeurDeltaOS13EtOS14 = rlocReponseValeurDeltaOS13EtOS14;
    }


    
    
}
