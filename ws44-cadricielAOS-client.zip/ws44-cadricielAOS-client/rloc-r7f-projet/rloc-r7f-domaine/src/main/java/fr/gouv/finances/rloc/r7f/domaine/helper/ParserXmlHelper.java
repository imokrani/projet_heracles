package fr.gouv.finances.rloc.r7f.domaine.helper;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import fr.gouv.finances.rloc.r7f.transverse.Resultats;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class ParserXmlHelper
{

    private static Resultats resultats = new Resultats();

    private static Map<String, Integer> indexParent = new HashMap<String, Integer>();
    
    public static Resultats parsersFichiersReponse(String repertoire, List<String> casDeTestListe) throws RecetteFonctionnelleException
    {
        for (String casDeTest : casDeTestListe)
        {
            parserFichierReponse(determinerNomFichier(repertoire, casDeTest), casDeTest);
        }
        
        return resultats;
    }
    
    /**
     * Déterminer le nom du fichier à partir du cas de test.
     *
     * @param fichierXML
     */
    private static String  determinerNomFichier(String repertoire, String casDeTest)
    {
        StringBuilder fichierXml = new StringBuilder();
        
        //on retire l'extension du fichier ods 
        String fichierODS = Parametres.getFichierODS().getName().replace(".ods", "_");
    
        //Construction du nom de ficher
        fichierXml.append(repertoire).append(File.separator)
            .append(fichierODS).append(casDeTest)
            .append(DateHelper.getDateTraitement()).append(".xml");
        
        return fichierXml.toString();
    }
    
    
    private static void parserFichierReponse(String fichierXML, String nomDuTest) throws RecetteFonctionnelleException
    {
        Document document = null;
        DOMParser parser = null;
        indexParent = new HashMap<String, Integer>();

        resultats.creerNouveauResultat(nomDuTest);

        try
        {
            parser = new DOMParser();
            parser.parse(fichierXML);
            document = parser.getDocument();

            parcourirNode("", document.getChildNodes());
        }
        catch (SAXException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
        catch (IOException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
    }

    private static void parcourirNode(String parent, NodeList nodeList)
    {
        for (int i = 0; i < nodeList.getLength(); i++)
        {
            String arborescence = parent + "/" + nodeList.item(i).getNodeName();

            Integer index = indexParent.get(arborescence);

            if (index == null)
            {
                index = 1;
            }
            else
            {
                index++;
            }

            indexParent.put(arborescence, index);

            arborescence = arborescence + "_" + index;

            Node node = nodeList.item(i);

            NodeList sousNodeList = node.getChildNodes();

            if (sousNodeList != null && sousNodeList.getLength() > 0)
            {
                parcourirNode(arborescence, sousNodeList);
            }
            else
            {
                String valeur = node.getNodeValue();

                if (!StringUtils.isBlank(valeur))
                {
                    resultats.ajouterValeur(arborescence, valeur);
                }
            }
        }
    }
    
}
