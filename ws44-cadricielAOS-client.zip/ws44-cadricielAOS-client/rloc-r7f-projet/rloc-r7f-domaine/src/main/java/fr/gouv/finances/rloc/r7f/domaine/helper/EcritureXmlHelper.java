package fr.gouv.finances.rloc.r7f.domaine.helper;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;

import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Constantes;
import fr.gouv.finances.rloc.r7f.transverse.constantes.Parametres;

public class EcritureXmlHelper
{

    public static final <T> void creerFichierReponseXml(T reponse, String nomDuTest, 
        Class classe, String wsdl) throws RecetteFonctionnelleException
    {
        String fichierXml = RecetteUtils.creerArborescenceFichierReponse(
             Parametres.getRepertoire().getAbsolutePath(), Parametres.getFichierODS().getName(),
             Parametres.getNomOS(), nomDuTest);

        JAXBContext jaxbContext;
        try
        {
            jaxbContext = JAXBContext.newInstance(classe);

            Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

            // format the XML output
            jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

            StringBuilder name = new StringBuilder(Constantes.PACKAGE_WSDL).append(wsdl.replace("?wsdl", "").replaceAll("/", "."));

            QName qName = new QName(name.toString(), "ReponseValeur");

            JAXBElement<T> root = new JAXBElement<T>(qName, classe, reponse);

            jaxbMarshaller.marshal(root, new File(fichierXml));
            
        }
        catch (JAXBException e)
        {
            throw new RecetteFonctionnelleException(e);
        }
    }
    
}
