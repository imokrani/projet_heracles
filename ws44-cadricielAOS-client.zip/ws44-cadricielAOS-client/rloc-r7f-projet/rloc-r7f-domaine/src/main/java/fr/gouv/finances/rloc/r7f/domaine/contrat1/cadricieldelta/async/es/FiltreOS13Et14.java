package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;



@XmlType(name = "", propOrder = {"adressesTopo","imgLocal"})
public class FiltreOS13Et14 implements java.io.Serializable
{
    /**
     * serialVersionUID - long, DOCUMENTEZ_MOI
     */
    private static final long serialVersionUID = -7402419275794691035L;

    private List<AdresseTopoOS13Et14> adressesTopo;

    private ImgLocalOS13Et14 imgLocal;

    public FiltreOS13Et14() 
    {
        
    }

    @XmlElement(name = "zoneGeographiqueListe")
    public List<AdresseTopoOS13Et14> getAdressesTopo()
    {
        return adressesTopo;
    }

    public void setAdressesTopo(List<AdresseTopoOS13Et14> adressesTopo)
    {
        this.adressesTopo = adressesTopo;
    }

    public ImgLocalOS13Et14 getImgLocal()
    {
        return imgLocal;
    }

    public void setImgLocal(ImgLocalOS13Et14 imgLocal)
    {
        this.imgLocal = imgLocal;
    }
    
}
