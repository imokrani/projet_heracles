package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


@XmlRootElement(name="rlocRequeteValeurOS13Et14")
@XmlType(name = "", propOrder = {"dtDebHisto","dtFinHisto","filtre"})
public class RlocRequeteValeurOS13Et14
{    

    private int num;
    private Date dtDebHisto;
    
    private Date dtFinHisto;
    
    private FiltreOS13Et14 filtre;

    @XmlElement(required = true)
    public Date getDtDebHisto()
    {
        return dtDebHisto;
    }

    public void setDtDebHisto(Date dtDebHisto)
    {
        this.dtDebHisto = dtDebHisto;
    }

    public Date getDtFinHisto()
    {
        return dtFinHisto;
    }

    public void setDtFinHisto(Date dtFinHisto)
    {
        this.dtFinHisto = dtFinHisto;
    }

    public FiltreOS13Et14 getFiltre()
    {
        return filtre;
    }

    public void setFiltre(FiltreOS13Et14 filtre)
    {
        this.filtre = filtre;
    }

    @XmlElement
    public int getNum()
    {
        return num;
    }

    public void setNum(int num)
    {
        this.num = num;
    }
}
