package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.delta;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.activation.DataHandler;
import javax.activation.FileDataSource;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.stream.FactoryConfigurationError;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamWriter;

import fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.DeltaLocalAsynchroneInterfaceImpl;
import fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.ov.AvancementValeur;
import fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.ov.ServiceAsynchroneValeur;
import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.delta.stubs.gen.RlocRequeteValeurOS13Et14;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.RechercherDeltaSurface;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.RechercherDeltaSurface.ServiceRequeteValeur2;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.RechercherDeltaSurface.ServiceRequeteValeur2.Filtre;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es.RechercherDeltaSurface.ServiceRequeteValeur2.Filtre.ZoneGeographiqueListe;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es.ImgLocalOS13Et14;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es.RlocReponseValeurDeltaOS13EtOS14;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es.RlocReponseValeurDeltaOS13EtOS14s;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.GenericUnMarshaller;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.ConstantesWSDL;
import fr.gouv.impots.appli.commun.frameworks.gestionressources.GestionnaireRessources;
import fr.gouv.impots.appli.commun.frameworks.gestionressources.transverse.RessourceFactoryJndiImpl;

public class DeltaTestAsync  extends TestSuite
{
    
    DeltaLocalAsynchroneInterfaceImpl  assitant ; 

    public DeltaTestAsync()
    {
        super(); 
    }
    
    @Override
    public void lancer() throws RecetteFonctionnelleException
    {
        assitant = creerService("DeltaLocalAsynchroneInterface", ConstantesWSDL.CADRICIEL_DELTA_ASYNC)
            .getPort(DeltaLocalAsynchroneInterfaceImpl.class);
        RecetteUtils.ajouterEnteteHTTP(assitant);
        
        GestionnaireRessources.setFactory(new RessourceFactoryJndiImpl());
            // DOCUMENTEZ_MOI Raccord de méthode auto-généré
        
        try
        {
            /** Preparer la requete avec l'ancienne XSD **/
            RechercherDeltaSurface rechercherDeltaSurface = new RechercherDeltaSurface(); 
            ServiceRequeteValeur2 serviceRequeteValeur2 = new ServiceRequeteValeur2(); 
            rechercherDeltaSurface.setServiceRequeteValeur2(serviceRequeteValeur2);
            serviceRequeteValeur2.setNum(0);
            serviceRequeteValeur2.setDtDebHisto(RecetteUtils.stringToXMLGregorianCalendar("2016-06-15"));
            serviceRequeteValeur2.setDtFinHisto(RecetteUtils.stringToXMLGregorianCalendar("2016-06-24"));
            ZoneGeographiqueListe  zoneGeographiqueListe = new ZoneGeographiqueListe(); 
            zoneGeographiqueListe.setCdDept("");
            zoneGeographiqueListe.setCdCommune("");
            zoneGeographiqueListe.setCdVoie(""); 
            
            ZoneGeographiqueListe zoneGeographiqueListe1 = new ZoneGeographiqueListe();
            zoneGeographiqueListe1.setCdDept("01");
            zoneGeographiqueListe1.setCdCommune("");
            zoneGeographiqueListe1.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe2 = new ZoneGeographiqueListe();
            zoneGeographiqueListe2.setCdDept("02");
            zoneGeographiqueListe2.setCdCommune("");
            zoneGeographiqueListe2.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe3 = new ZoneGeographiqueListe();
            zoneGeographiqueListe3.setCdDept("03");
            zoneGeographiqueListe3.setCdCommune("");
            zoneGeographiqueListe3.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe4 = new ZoneGeographiqueListe();
            zoneGeographiqueListe4.setCdDept("04");
            zoneGeographiqueListe4.setCdCommune("");
            zoneGeographiqueListe4.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe5 = new ZoneGeographiqueListe();
            zoneGeographiqueListe5.setCdDept("05");
            zoneGeographiqueListe5.setCdCommune("");
            zoneGeographiqueListe5.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe6 = new ZoneGeographiqueListe();
            zoneGeographiqueListe6.setCdDept("06");
            zoneGeographiqueListe6.setCdCommune("");
            zoneGeographiqueListe6.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe7 = new ZoneGeographiqueListe();
            zoneGeographiqueListe7.setCdDept("07");
            zoneGeographiqueListe7.setCdCommune("");
            zoneGeographiqueListe7.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe8 = new ZoneGeographiqueListe();
            zoneGeographiqueListe8.setCdDept("08");
            zoneGeographiqueListe8.setCdCommune("");
            zoneGeographiqueListe8.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe9 = new ZoneGeographiqueListe();
            zoneGeographiqueListe9.setCdDept("09");
            zoneGeographiqueListe9.setCdCommune("");
            zoneGeographiqueListe9.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe10 = new ZoneGeographiqueListe();
            zoneGeographiqueListe10.setCdDept("10");
            zoneGeographiqueListe10.setCdCommune("");
            zoneGeographiqueListe10.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe11 = new ZoneGeographiqueListe();
            zoneGeographiqueListe11.setCdDept("11");
            zoneGeographiqueListe11.setCdCommune("");
            zoneGeographiqueListe11.setCdVoie("");
            

            ZoneGeographiqueListe zoneGeographiqueListe12 = new ZoneGeographiqueListe();
            zoneGeographiqueListe12.setCdDept("12");
            zoneGeographiqueListe12.setCdCommune("");
            zoneGeographiqueListe12.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe13 = new ZoneGeographiqueListe();
            zoneGeographiqueListe13.setCdDept("13");
            zoneGeographiqueListe13.setCdCommune("");
            zoneGeographiqueListe13.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe14 = new ZoneGeographiqueListe();
            zoneGeographiqueListe14.setCdDept("14");
            zoneGeographiqueListe14.setCdCommune("");
            zoneGeographiqueListe14.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe15 = new ZoneGeographiqueListe();
            zoneGeographiqueListe15.setCdDept("15");
            zoneGeographiqueListe15.setCdCommune("");
            zoneGeographiqueListe15.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe16 = new ZoneGeographiqueListe();
            zoneGeographiqueListe16.setCdDept("16");
            zoneGeographiqueListe16.setCdCommune("");
            zoneGeographiqueListe16.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe45 = new ZoneGeographiqueListe();
            zoneGeographiqueListe45.setCdDept("45");
            zoneGeographiqueListe45.setCdCommune("");
            zoneGeographiqueListe45.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe78 = new ZoneGeographiqueListe();
            zoneGeographiqueListe78.setCdDept("78");
            zoneGeographiqueListe78.setCdCommune("");
            zoneGeographiqueListe78.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe92 = new ZoneGeographiqueListe();
            zoneGeographiqueListe92.setCdDept("92");
            zoneGeographiqueListe92.setCdCommune("");
            zoneGeographiqueListe92.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe95 = new ZoneGeographiqueListe();
            zoneGeographiqueListe95.setCdDept("95");
            zoneGeographiqueListe95.setCdCommune("");
            zoneGeographiqueListe95.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe94 = new ZoneGeographiqueListe();
            zoneGeographiqueListe94.setCdDept("94");
            zoneGeographiqueListe94.setCdCommune("");
            zoneGeographiqueListe94.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe93 = new ZoneGeographiqueListe();
            zoneGeographiqueListe93.setCdDept("93");
            zoneGeographiqueListe93.setCdCommune("");
            zoneGeographiqueListe93.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe91 = new ZoneGeographiqueListe();
            zoneGeographiqueListe91.setCdDept("91");
            zoneGeographiqueListe91.setCdCommune("");
            zoneGeographiqueListe91.setCdVoie("");
            
            ZoneGeographiqueListe zoneGeographiqueListe90 = new ZoneGeographiqueListe();
            zoneGeographiqueListe90.setCdDept("90");
            zoneGeographiqueListe90.setCdCommune("");
            zoneGeographiqueListe90.setCdVoie("");
            
            
            Filtre filtre = new Filtre(); 
            List<ZoneGeographiqueListe> listeZone = filtre.getZoneGeographiqueListe(); 
            listeZone.add(zoneGeographiqueListe);
//            listeZone.add(zoneGeographiqueListe1);
//            listeZone.add(zoneGeographiqueListe2);
//            listeZone.add(zoneGeographiqueListe3);
//            listeZone.add(zoneGeographiqueListe4);
//            listeZone.add(zoneGeographiqueListe5);
//            listeZone.add(zoneGeographiqueListe6);
//            listeZone.add(zoneGeographiqueListe7);
//            listeZone.add(zoneGeographiqueListe8);
//            listeZone.add(zoneGeographiqueListe9);
//            listeZone.add(zoneGeographiqueListe10);
//            listeZone.add(zoneGeographiqueListe11);
//            listeZone.add(zoneGeographiqueListe12);
//            listeZone.add(zoneGeographiqueListe13);
//            listeZone.add(zoneGeographiqueListe14);
//            listeZone.add(zoneGeographiqueListe15);
//            listeZone.add(zoneGeographiqueListe16);
//            listeZone.add(zoneGeographiqueListe45);
//            listeZone.add(zoneGeographiqueListe78);
//            listeZone.add(zoneGeographiqueListe92);
//            listeZone.add(zoneGeographiqueListe95);
//            listeZone.add(zoneGeographiqueListe93);
//            listeZone.add(zoneGeographiqueListe94);
//            listeZone.add(zoneGeographiqueListe91);
//            listeZone.add(zoneGeographiqueListe90);
            
            ImgLocalOS13Et14 imgLocal = new ImgLocalOS13Et14(); 
            imgLocal.setTypeDesc("");
            filtre.setImgLocal(imgLocal);
            serviceRequeteValeur2.setFiltre(filtre);
            
            /** Generer un Datahandler **/
            File fileTemp = null;
            DataHandler dataHandlerRequete = null; 
            try
            {
                fileTemp = File.createTempFile("TestCadricielDelta", ".xml");
                JAXBContext context = JAXBContext.newInstance(RechercherDeltaSurface.class);
                Marshaller marshaller = context.createMarshaller(); 
                marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");
                marshaller.setProperty(Marshaller.JAXB_FRAGMENT, Boolean.TRUE);
                marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
                FileOutputStream outputStream =new FileOutputStream(fileTemp);
                XMLStreamWriter xmlWriter = XMLOutputFactory.newInstance().createXMLStreamWriter(outputStream, "UTF-8"); 
                xmlWriter.writeStartDocument("UTF-8", "1.0");
                //xmlWriter.writeStartElement("rechercherDeltaSurface");
                JAXBElement<RechercherDeltaSurface> element = new JAXBElement<RechercherDeltaSurface>(QName.valueOf("rechercherDeltaSurface"), RechercherDeltaSurface.class, rechercherDeltaSurface); 
                marshaller.marshal(element, xmlWriter);
                xmlWriter.flush();
                xmlWriter.writeEndDocument();
                xmlWriter.close();             
                outputStream.close();
                FileDataSource fileDataSource = new FileDataSource(fileTemp); 
                dataHandlerRequete = new DataHandler(fileDataSource);
            }
            catch (IOException | JAXBException | XMLStreamException | FactoryConfigurationError e1)
            {
                //Erreur de génération de la pièce jointe
            }
            
            //Instant de depart 
            long debut = System.currentTimeMillis();
            /** Récupération d'un IEIS **/
            long debutObtenirIEIS = System.currentTimeMillis();
            byte[] ieis = assitant.obtenirIEIS();
            long finObtenirIEIS = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface Obtenir IEIS  Durée exécution : " + (finObtenirIEIS - debutObtenirIEIS));
           
            ServiceAsynchroneValeur serviceAsynchroneValeur = new ServiceAsynchroneValeur(); 
            serviceAsynchroneValeur.setIeis(ieis);            
            
            /** Appel du service **/
            long debutAppelSrv = System.currentTimeMillis();
            assitant.rechercherDeltaSurface(serviceAsynchroneValeur, dataHandlerRequete);
            long finAppelSrv = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface Appel service  Durée exécution : " + (finAppelSrv - debutAppelSrv));
            
            long debutAvancement = System.currentTimeMillis();
            AvancementValeur avancementValeur = null;
            long moyen =0; 
            int cpt =1; 
            do
            {   
                try
                {
                    Thread.sleep(5000);
                }
                catch (InterruptedException e)
                {
                    throw new RecetteFonctionnelleException(e);
                }
                long debutAppelAvan = System.currentTimeMillis();
                avancementValeur = assitant.obtenirAvancement(serviceAsynchroneValeur); 
                long finAppelAvan = System.currentTimeMillis();
                System.out.println("obtenirAvancement  Durée exécution : " + (finAppelAvan - debutAppelAvan));
                moyen = moyen + (finAppelAvan - debutAppelAvan); 
                cpt++;
            }
            // la valeur "4" du statut de l'IEIS indique que le traitement est en cours de réalisation
            while (avancementValeur.getInfoAvancement().getStatut() == 4);
            System.out.println("obtenirAvancement  Moyenne appel : " + moyen /cpt);
            long finAvancement = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface Obtenir avancement  Durée exécution : " + getDureeTraitement(finAvancement - debutAvancement));
            /** Recupération de réponse **/
            long debutResultat = System.currentTimeMillis();
            DataHandler dataHandlerRepo   = assitant.resultatRechercherDeltaSurface(serviceAsynchroneValeur); 
            long finResultat = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface  Durée restitution des resultat : " + (finResultat - debutResultat));
            /** Acquittement **/
            long debutAcquitter = System.currentTimeMillis();
            assitant.acquitter(serviceAsynchroneValeur);
            long finAcquitter = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface  Durée Acquittement : " + (finAcquitter - debutAcquitter));
            long fin = System.currentTimeMillis();
            System.out.println("Service: RechercherDeltaSurface  Durée exécution totale : " + getDureeTraitement(fin - debut));
            
            
            List<RlocReponseValeurDeltaOS13EtOS14>  listeReponsesValeur = new ArrayList<RlocReponseValeurDeltaOS13EtOS14>();
            try
            {
                GenericUnMarshaller<RlocReponseValeurDeltaOS13EtOS14> xmlStreamReader = null;
                InputStream inputStream = dataHandlerRepo.getInputStream();
                xmlStreamReader = new GenericUnMarshaller<RlocReponseValeurDeltaOS13EtOS14>(inputStream, RlocReponseValeurDeltaOS13EtOS14.class);
                while (xmlStreamReader.elementSuivant())
                {
                    RlocReponseValeurDeltaOS13EtOS14 articleReponse = xmlStreamReader.suivant();
                    listeReponsesValeur.add(articleReponse);
                    System.out.println(" --> Le nombre de locaux restit : "+articleReponse.getReponse().getIdsLocal().size());
                }
                inputStream.close();
            }
            catch (IOException | XMLStreamException | FactoryConfigurationError | JAXBException e)
            {
                System.out.println("Erreur de desrialisation ");
                e.printStackTrace();
            }
            
            /** Enregistrement sur disque une copie de la PJ generée **/
//            byte[] bytes = null;
//            ByteArrayOutputStream bos = new ByteArrayOutputStream();  
//            try
//            {
//              dataHandlerRequete.writeTo(bos);
//              bos.flush();
//              bos.close();
//              bytes = bos.toByteArray();
//              FileOutputStream fos = new FileOutputStream("C:/Temp/RequeteDeltaPJ.xml");
//              fos.write(bytes);
//              fos.close();
//            }
//            catch (IOException e1)
//            {
//              //Erreur d'enregistrement de PJ sur Disque 
//            }
            
          
           
          
            /** Enregistrer la reponse sur disque **/
            byte[] bytesRep = null;
            ByteArrayOutputStream bosRep = new ByteArrayOutputStream();  
            try
            {
                dataHandlerRepo.writeTo(bosRep);
                bosRep.flush();
                bosRep.close();
                bytesRep = bosRep.toByteArray();
                FileOutputStream fosRep = new FileOutputStream("C:/Temp/ReponseDeltaPJ.xml");
                fosRep.write(bytesRep);
                fosRep.close();
            }
            catch (IOException e1)
            {
                //Erreur d'enregistrement de PJ sur Disque 
            }
            
           
        }
        catch (fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.TechDysfonctionnementException e)
        {
        }
        catch (fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.TechIndisponibiliteException e)
        {
        }
        catch (fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.TechProtocolaireException e)
        {
            
        }  
    }
    
    public static String getDureeTraitement(long duree_millis)
    {   
        StringBuilder sb = new StringBuilder(64);
        
        try {
        
            long jours = TimeUnit.MILLISECONDS.toDays(duree_millis);
            duree_millis -= TimeUnit.DAYS.toMillis(jours);
        
            long heures = TimeUnit.MILLISECONDS.toHours(duree_millis);
            duree_millis -= TimeUnit.HOURS.toMillis(heures);
        
            long minutes = TimeUnit.MILLISECONDS.toMinutes(duree_millis);
            duree_millis -= TimeUnit.MINUTES.toMillis(minutes);
        
            long secondes = TimeUnit.MILLISECONDS.toSeconds(duree_millis);

            if (jours != 0) {
                sb.append(jours);
                sb.append(" jours ");
            }
            
            if (heures != 0) {
                sb.append(heures);
                sb.append(" heures ");
            }
            
            if (minutes != 0) {
                sb.append(minutes);
                sb.append(" minutes ");
            }
            
            sb.append(secondes);
            sb.append("secondes");

        } 
        catch (Exception e) {

            sb = null;
            System.out.println(e.getMessage());
            
        }
        
        return(sb.toString());
        
    }

}
