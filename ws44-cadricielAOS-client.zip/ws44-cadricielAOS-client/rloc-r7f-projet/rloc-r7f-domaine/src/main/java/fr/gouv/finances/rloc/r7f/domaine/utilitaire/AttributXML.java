package fr.gouv.finances.rloc.r7f.domaine.utilitaire;

/**
 * 
 * AttributXML.java
 * Attribut XML nom ; valeur
 * @author mokranii
 * Date: 24 sept. 2016
 */
public class AttributXML
{
    private static final String NOM_NULL = "NomIsNull"; 
    private static final String Valeur_NULL = "ValeurIsNull"; 
    private String nom; 
    private String valeur; 
    
    public AttributXML(String nom, String valeur)
    {
        if(nom != null)
        {
            this.nom = nom;
        }
        else
        {
            this.nom = NOM_NULL; 
        }
        
        if(valeur != null)
        {
            this.valeur = valeur; 
        }
        else
        {
            this.valeur = Valeur_NULL; 
        }
    }

    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public String getValeur()
    {
        return valeur;
    }

    public void setValeur(String valeur)
    {
        this.valeur = valeur;
    }

    @Override
    public String toString()
    {
        return "AttributXML [nom=" + nom + ", valeur=" + valeur + "]";
    }
}
