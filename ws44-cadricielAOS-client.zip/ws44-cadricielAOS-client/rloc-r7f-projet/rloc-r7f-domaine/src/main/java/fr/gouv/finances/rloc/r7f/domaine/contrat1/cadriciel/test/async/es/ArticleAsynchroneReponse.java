//
// Ce fichier a été généré par l'implémentation de référence JavaTM Architecture for XML Binding (JAXB), v2.2.11 
// Voir <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Toute modification apportée à ce fichier sera perdue lors de la recompilation du schéma source. 
// Généré le : 2016.11.16 à 05:32:30 PM CET 
//


package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Classe Java pour articleAsynchroneReponse complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="articleAsynchroneReponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;extension base="{}articleSynchroneReponse"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="techDysfonctionnementErreur" type="{}techDysfonctionnementErreur" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/extension&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "articleAsynchroneReponse", propOrder = {
    "techDysfonctionnementErreur"
})
@XmlSeeAlso({
    ProjetReponseDto.class
})
public class ArticleAsynchroneReponse
    extends ArticleSynchroneReponse
{

    protected TechDysfonctionnementErreur techDysfonctionnementErreur;

    /**
     * Obtient la valeur de la propriété techDysfonctionnementErreur.
     * 
     * @return
     *     possible object is
     *     {@link TechDysfonctionnementErreur }
     *     
     */
    public TechDysfonctionnementErreur getTechDysfonctionnementErreur() {
        return techDysfonctionnementErreur;
    }

    /**
     * Définit la valeur de la propriété techDysfonctionnementErreur.
     * 
     * @param value
     *     allowed object is
     *     {@link TechDysfonctionnementErreur }
     *     
     */
    public void setTechDysfonctionnementErreur(TechDysfonctionnementErreur value) {
        this.techDysfonctionnementErreur = value;
    }

}
