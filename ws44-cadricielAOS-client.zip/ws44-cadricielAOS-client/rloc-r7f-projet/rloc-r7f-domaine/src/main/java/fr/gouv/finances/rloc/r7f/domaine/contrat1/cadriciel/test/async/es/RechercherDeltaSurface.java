
package fr.gouv.finances.rloc.r7f.domaine.contrat1.cadriciel.test.async.es;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;

import fr.gouv.finances.aos.mas.service.stubs.delta.asynchrone.ov.ServiceAsynchroneValeur;
import fr.gouv.finances.rloc.r7f.domaine.contrat1.cadricieldelta.async.es.ImgLocalOS13Et14;


/**
 * <p>Classe Java pour rechercherDeltaSurface complex type.
 * 
 * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
 * 
 * <pre>
 * &lt;complexType name="rechercherDeltaSurface">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="serviceAsynchrone" type="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}serviceAsynchroneValeur" minOccurs="0"/>
 *         &lt;element name="serviceRequeteValeur_2" minOccurs="0">
 *           &lt;complexType>
 *             &lt;complexContent>
 *               &lt;extension base="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}articleRequete">
 *                 &lt;sequence>
 *                   &lt;element name="dtDebHisto" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *                   &lt;element name="dtFinHisto" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
 *                   &lt;element name="filtre" minOccurs="0">
 *                     &lt;complexType>
 *                       &lt;complexContent>
 *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                           &lt;sequence>
 *                             &lt;element name="zoneGeographiqueListe" maxOccurs="unbounded" minOccurs="0">
 *                               &lt;complexType>
 *                                 &lt;complexContent>
 *                                   &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *                                     &lt;sequence>
 *                                       &lt;element name="cdDept" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *                                       &lt;element name="cdCommune" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                       &lt;element name="cdVoie" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *                                     &lt;/sequence>
 *                                   &lt;/restriction>
 *                                 &lt;/complexContent>
 *                               &lt;/complexType>
 *                             &lt;/element>
 *                             &lt;element name="imgLocal" type="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}imgLocalOS13Et14" minOccurs="0"/>
 *                           &lt;/sequence>
 *                         &lt;/restriction>
 *                       &lt;/complexContent>
 *                     &lt;/complexType>
 *                   &lt;/element>
 *                 &lt;/sequence>
 *               &lt;/extension>
 *             &lt;/complexContent>
 *           &lt;/complexType>
 *         &lt;/element>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "rechercherDeltaSurface", propOrder = {
    "serviceAsynchrone",
    "serviceRequeteValeur2"
})
public class RechercherDeltaSurface {

    protected ServiceAsynchroneValeur serviceAsynchrone;
    @XmlElement(name = "serviceRequeteValeur_2")
    protected RechercherDeltaSurface.ServiceRequeteValeur2 serviceRequeteValeur2;

    /**
     * Obtient la valeur de la propriété serviceAsynchrone.
     * 
     * @return
     *     possible object is
     *     {@link ServiceAsynchroneValeur }
     *     
     */
    public ServiceAsynchroneValeur getServiceAsynchrone() {
        return serviceAsynchrone;
    }

    /**
     * Définit la valeur de la propriété serviceAsynchrone.
     * 
     * @param value
     *     allowed object is
     *     {@link ServiceAsynchroneValeur }
     *     
     */
    public void setServiceAsynchrone(ServiceAsynchroneValeur value) {
        this.serviceAsynchrone = value;
    }

    /**
     * Obtient la valeur de la propriété serviceRequeteValeur2.
     * 
     * @return
     *     possible object is
     *     {@link RechercherDeltaSurface.ServiceRequeteValeur2 }
     *     
     */
    public RechercherDeltaSurface.ServiceRequeteValeur2 getServiceRequeteValeur2() {
        return serviceRequeteValeur2;
    }

    /**
     * Définit la valeur de la propriété serviceRequeteValeur2.
     * 
     * @param value
     *     allowed object is
     *     {@link RechercherDeltaSurface.ServiceRequeteValeur2 }
     *     
     */
    public void setServiceRequeteValeur2(RechercherDeltaSurface.ServiceRequeteValeur2 value) {
        this.serviceRequeteValeur2 = value;
    }


    /**
     * <p>Classe Java pour anonymous complex type.
     * 
     * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
     * 
     * <pre>
     * &lt;complexType>
     *   &lt;complexContent>
     *     &lt;extension base="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}articleRequete">
     *       &lt;sequence>
     *         &lt;element name="dtDebHisto" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
     *         &lt;element name="dtFinHisto" type="{http://www.w3.org/2001/XMLSchema}dateTime" minOccurs="0"/>
     *         &lt;element name="filtre" minOccurs="0">
     *           &lt;complexType>
     *             &lt;complexContent>
     *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                 &lt;sequence>
     *                   &lt;element name="zoneGeographiqueListe" maxOccurs="unbounded" minOccurs="0">
     *                     &lt;complexType>
     *                       &lt;complexContent>
     *                         &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
     *                           &lt;sequence>
     *                             &lt;element name="cdDept" type="{http://www.w3.org/2001/XMLSchema}string"/>
     *                             &lt;element name="cdCommune" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                             &lt;element name="cdVoie" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
     *                           &lt;/sequence>
     *                         &lt;/restriction>
     *                       &lt;/complexContent>
     *                     &lt;/complexType>
     *                   &lt;/element>
     *                   &lt;element name="imgLocal" type="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}imgLocalOS13Et14" minOccurs="0"/>
     *                 &lt;/sequence>
     *               &lt;/restriction>
     *             &lt;/complexContent>
     *           &lt;/complexType>
     *         &lt;/element>
     *       &lt;/sequence>
     *     &lt;/extension>
     *   &lt;/complexContent>
     * &lt;/complexType>
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "dtDebHisto",
        "dtFinHisto",
        "filtre"
    })
    public static class ServiceRequeteValeur2
        extends ArticleRequete
    {

        @XmlElement(required = true)
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar dtDebHisto;
        @XmlSchemaType(name = "dateTime")
        protected XMLGregorianCalendar dtFinHisto;
        protected RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre filtre;

        /**
         * Obtient la valeur de la propriété dtDebHisto.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDtDebHisto() {
            return dtDebHisto;
        }

        /**
         * Définit la valeur de la propriété dtDebHisto.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDtDebHisto(XMLGregorianCalendar value) {
            this.dtDebHisto = value;
        }

        /**
         * Obtient la valeur de la propriété dtFinHisto.
         * 
         * @return
         *     possible object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public XMLGregorianCalendar getDtFinHisto() {
            return dtFinHisto;
        }

        /**
         * Définit la valeur de la propriété dtFinHisto.
         * 
         * @param value
         *     allowed object is
         *     {@link XMLGregorianCalendar }
         *     
         */
        public void setDtFinHisto(XMLGregorianCalendar value) {
            this.dtFinHisto = value;
        }

        /**
         * Obtient la valeur de la propriété filtre.
         * 
         * @return
         *     possible object is
         *     {@link RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre }
         *     
         */
        public RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre getFiltre() {
            return filtre;
        }

        /**
         * Définit la valeur de la propriété filtre.
         * 
         * @param value
         *     allowed object is
         *     {@link RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre }
         *     
         */
        public void setFiltre(RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre value) {
            this.filtre = value;
        }


        /**
         * <p>Classe Java pour anonymous complex type.
         * 
         * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
         * 
         * <pre>
         * &lt;complexType>
         *   &lt;complexContent>
         *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *       &lt;sequence>
         *         &lt;element name="zoneGeographiqueListe" maxOccurs="unbounded" minOccurs="0">
         *           &lt;complexType>
         *             &lt;complexContent>
         *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
         *                 &lt;sequence>
         *                   &lt;element name="cdDept" type="{http://www.w3.org/2001/XMLSchema}string"/>
         *                   &lt;element name="cdCommune" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                   &lt;element name="cdVoie" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
         *                 &lt;/sequence>
         *               &lt;/restriction>
         *             &lt;/complexContent>
         *           &lt;/complexType>
         *         &lt;/element>
         *         &lt;element name="imgLocal" type="{http://service.rloc.appli.impots.gouv.fr/services/contrat_rlocmas_delta_1/DeltaLocalAsynchroneInterface}imgLocalOS13Et14" minOccurs="0"/>
         *       &lt;/sequence>
         *     &lt;/restriction>
         *   &lt;/complexContent>
         * &lt;/complexType>
         * </pre>
         * 
         * 
         */
        @XmlAccessorType(XmlAccessType.FIELD)
        @XmlType(name = "", propOrder = {
            "zoneGeographiqueListe",
            "imgLocal"
        })
        public static class Filtre {

            protected List<RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre.ZoneGeographiqueListe> zoneGeographiqueListe;
            protected ImgLocalOS13Et14 imgLocal;

            /**
             * Gets the value of the zoneGeographiqueListe property.
             * 
             * <p>
             * This accessor method returns a reference to the live list,
             * not a snapshot. Therefore any modification you make to the
             * returned list will be present inside the JAXB object.
             * This is why there is not a <CODE>set</CODE> method for the zoneGeographiqueListe property.
             * 
             * <p>
             * For example, to add a new item, do as follows:
             * <pre>
             *    getZoneGeographiqueListe().add(newItem);
             * </pre>
             * 
             * 
             * <p>
             * Objects of the following type(s) are allowed in the list
             * {@link RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre.ZoneGeographiqueListe }
             * 
             * 
             */
            public List<RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre.ZoneGeographiqueListe> getZoneGeographiqueListe() {
                if (zoneGeographiqueListe == null) {
                    zoneGeographiqueListe = new ArrayList<RechercherDeltaSurface.ServiceRequeteValeur2 .Filtre.ZoneGeographiqueListe>();
                }
                return this.zoneGeographiqueListe;
            }

            /**
             * Obtient la valeur de la propriété imgLocal.
             * 
             * @return
             *     possible object is
             *     {@link ImgLocalOS13Et14 }
             *     
             */
            public ImgLocalOS13Et14 getImgLocal() {
                return imgLocal;
            }

            /**
             * Définit la valeur de la propriété imgLocal.
             * 
             * @param value
             *     allowed object is
             *     {@link ImgLocalOS13Et14 }
             *     
             */
            public void setImgLocal(ImgLocalOS13Et14 value) {
                this.imgLocal = value;
            }


            /**
             * <p>Classe Java pour anonymous complex type.
             * 
             * <p>Le fragment de schéma suivant indique le contenu attendu figurant dans cette classe.
             * 
             * <pre>
             * &lt;complexType>
             *   &lt;complexContent>
             *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
             *       &lt;sequence>
             *         &lt;element name="cdDept" type="{http://www.w3.org/2001/XMLSchema}string"/>
             *         &lt;element name="cdCommune" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *         &lt;element name="cdVoie" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
             *       &lt;/sequence>
             *     &lt;/restriction>
             *   &lt;/complexContent>
             * &lt;/complexType>
             * </pre>
             * 
             * 
             */
            @XmlAccessorType(XmlAccessType.FIELD)
            @XmlType(name = "", propOrder = {
                "cdDept",
                "cdCommune",
                "cdVoie"
            })
            public static class ZoneGeographiqueListe {

                @XmlElement(required = true)
                protected String cdDept;
                protected String cdCommune;
                protected String cdVoie;

                /**
                 * Obtient la valeur de la propriété cdDept.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdDept() {
                    return cdDept;
                }

                /**
                 * Définit la valeur de la propriété cdDept.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdDept(String value) {
                    this.cdDept = value;
                }

                /**
                 * Obtient la valeur de la propriété cdCommune.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdCommune() {
                    return cdCommune;
                }

                /**
                 * Définit la valeur de la propriété cdCommune.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdCommune(String value) {
                    this.cdCommune = value;
                }

                /**
                 * Obtient la valeur de la propriété cdVoie.
                 * 
                 * @return
                 *     possible object is
                 *     {@link String }
                 *     
                 */
                public String getCdVoie() {
                    return cdVoie;
                }

                /**
                 * Définit la valeur de la propriété cdVoie.
                 * 
                 * @param value
                 *     allowed object is
                 *     {@link String }
                 *     
                 */
                public void setCdVoie(String value) {
                    this.cdVoie = value;
                }

            }

        }

    }

}
