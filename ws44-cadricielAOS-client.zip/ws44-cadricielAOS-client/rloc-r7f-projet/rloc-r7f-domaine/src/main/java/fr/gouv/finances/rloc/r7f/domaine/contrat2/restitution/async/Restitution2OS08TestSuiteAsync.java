package fr.gouv.finances.rloc.r7f.domaine.contrat2.restitution.async;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.AvancementValeur;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.RestitutionLocalAsynchroneInterface;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.RlocListeReponseAsyncValeurOS8;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.RlocRequeteLocalOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.RlocRequeteParametresOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.RlocRequeteValeurOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.ServiceAsynchroneValeur;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.SousRequeteValeurOS08;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.TechDysfonctionnementErreur_Exception;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.TechIndisponibiliteErreur_Exception;
import fr.gouv.finances.rloc.r7f.contrat2.restitution.async.TechProtocolaireErreur_Exception;
import fr.gouv.finances.rloc.r7f.domaine.TestSuite;
import fr.gouv.finances.rloc.r7f.domaine.helper.EcritureOdsHelper;
import fr.gouv.finances.rloc.r7f.domaine.helper.EcritureXmlHelper;
import fr.gouv.finances.rloc.r7f.domaine.utilitaire.RecetteUtils;
import fr.gouv.finances.rloc.r7f.transverse.Exception.RecetteFonctionnelleException;
import fr.gouv.finances.rloc.r7f.transverse.constantes.ConstantesWSDL;

public class Restitution2OS08TestSuiteAsync extends TestSuite
{
    private RestitutionLocalAsynchroneInterface restitution;

    public Restitution2OS08TestSuiteAsync()
    {
        super();
    }

    public void lancer() throws RecetteFonctionnelleException
    {
        // Construction de la requête
        Map<String, RlocRequeteValeurOS08> map = mappingFichierODS();

        restitution = creerService("RestitutionLocalAsynchroneInterface", ConstantesWSDL.RESTITUTION_ASYNC)
                .getPort(RestitutionLocalAsynchroneInterface.class);
        
        RecetteUtils.ajouterEnteteHTTP(restitution);
        
        for (String nomDuTest : casDeTest)
        {   
            // Appel du service
            RlocListeReponseAsyncValeurOS8 reponse = executerRequete(map.get(nomDuTest));

            // Constrution de la réponse
            EcritureXmlHelper.creerFichierReponseXml(reponse, nomDuTest, RlocListeReponseAsyncValeurOS8.class, ConstantesWSDL.RESTITUTION_ASYNC); 
        }
        
        EcritureOdsHelper.creerFichierReponseODS(casDeTest);
    }

    public Map<String, RlocRequeteValeurOS08> mappingFichierODS() throws RecetteFonctionnelleException
    {
        Map<String, RlocRequeteValeurOS08> map = new HashMap<String, RlocRequeteValeurOS08>();

        initSheet();

        int nbColonne = sheet.getColumnCount();

        // mapping fichier ods
        for (int i = 2; i <= nbColonne; i++)
        {
            ligne = 0;
            colonne = i;

            RlocRequeteValeurOS08 requete = new RlocRequeteValeurOS08();
            List<SousRequeteValeurOS08> listeSousRequete = requete.getRequete();

            String nomDuTest = getNextValueSheet();

            if (nomDuTest.equals(""))
            {
                break;
            }

            RlocRequeteLocalOS08 local = new RlocRequeteLocalOS08();
            local.setIdLocal(getNextValueSheet());
            RlocRequeteParametresOS08 lecture = new RlocRequeteParametresOS08();
  
            lecture.setDtValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setDtDebutValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setDtFinValidite(RecetteUtils.stringToXMLGregorianCalendar(getNextValueSheet()));
            lecture.setLbValidite(getNextValueSheet());
            lecture.setLbHistorisation(getNextValueSheet());

            SousRequeteValeurOS08 sousRequete = new SousRequeteValeurOS08();
            sousRequete.setLocal(local);
            sousRequete.setLecture(lecture);

            listeSousRequete.add(sousRequete);
            map.put(nomDuTest, requete);            
            casDeTest.add(nomDuTest);
        }

        return map;
    }

    public RlocListeReponseAsyncValeurOS8 executerRequete(RlocRequeteValeurOS08 serviceRequeteValeur2) throws RecetteFonctionnelleException
    {
        RlocListeReponseAsyncValeurOS8 reponse = null;

        try
        {
            byte[] ieis = restitution.obtenirIEIS();
            
            ServiceAsynchroneValeur serviceValeur = new ServiceAsynchroneValeur();
            serviceValeur.setIeis(ieis);
            
            restitution.restituerLocalEtVlGlobaliseeParIdLocal(serviceValeur, serviceRequeteValeur2);
            /*
             * Corriger le lancement de la méthode pour obtenir l'avancement   dans les autres services asynchrone
             */
//            AvancementValeur avancementValeur =null; 
//            do
//            {   
//                try
//                {
//                    Thread.sleep(1000);
//                     avancementValeur = restitution.obtenirAvancement(serviceValeur); 
//                }
//                catch (InterruptedException e)
//                {
//                    throw new RecetteFonctionnelleException(e);
//                }
//            }
//            // la valeur "4" du statut de l'IEIS indique que le traitement est en cours de réalisation
//            while (avancementValeur.getInfoAvancement().getStatut() != 5); 
            AvancementValeur avancementValeur = restitution.obtenirAvancement(serviceValeur); 
            while (avancementValeur.getInfoAvancement().getStatut() != 5)
            {
                avancementValeur = restitution.obtenirAvancement(serviceValeur);  
            }
            reponse = restitution.resultatRestituerLocalEtVlGlobaliseeParIdLocal(serviceValeur);
            restitution.acquitter(serviceValeur);
        }
        catch (TechDysfonctionnementErreur_Exception e)
        {
            String message = "Erreur lors de l'execution du service";
            throw new RecetteFonctionnelleException(message, e);
        }
        catch (TechProtocolaireErreur_Exception e)
        {
            String message = "Erreur protocolaire lors de l'execution du service";
            throw new RecetteFonctionnelleException(message, e);
        }
        catch (TechIndisponibiliteErreur_Exception e)
        {
            String message = "Le service est indisponible";
            throw new RecetteFonctionnelleException(message, e);
        }

        return reponse;
    }
}
