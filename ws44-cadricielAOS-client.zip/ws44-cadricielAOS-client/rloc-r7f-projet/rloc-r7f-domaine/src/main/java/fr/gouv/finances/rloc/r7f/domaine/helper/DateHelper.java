package fr.gouv.finances.rloc.r7f.domaine.helper;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DateHelper
{

    private static String dateTraitement = "";
    
    
    public static String getDateTraitement()
    {
        if (dateTraitement.equals(""))
        {
            // Récupérer la date du traitement
            Date date = new Date();
            DateFormat df = new SimpleDateFormat("_yyyymmdd_hhmmss", Locale.FRENCH);
            dateTraitement = df.format(date);
        }

        return dateTraitement;
    }
    
}
